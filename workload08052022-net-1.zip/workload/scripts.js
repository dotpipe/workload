function callIndex() {
  var xhttp4 = new XMLHttpRequest();
  xhttp4.onreadystatechange = function() {
    if (xhttp4.readyState == 4 && xhttp4.status == 200) {
	document.getElementById("idFullPage").innerHTML = xhttp4.responseText;
	//document.getElementById("showincPage").style.display = 'block';
    }
  };
  var c = "PHP/workload.php";
  xhttp4.open("POST", c, true);
  xhttp4.send();
}

function callLogger() {
  var xhttp2 = new XMLHttpRequest();
  xhttp2.onreadystatechange = function() {
    if (xhttp2.readyState == 4 && xhttp2.status == 200) {
	document.getElementById("showLog").innerHTML = xhttp2.responseText;
	document.getElementById("showLog").style.display = 'block';
    }
  };
  c = "log/backlog.php";
  xhttp2.open("GET", c, true);
  xhttp2.send();
}

function deactiveDate(indx) {
  var xhttp2 = new XMLHttpRequest();
  c = "PHP/serverside.php?deactive_date=1&n="+indx;
  xhttp2.open("POST", c, true);
  xhttp2.send();
}

function activeDate(indx) {
  var xhttp2 = new XMLHttpRequest();
  c = "PHP/serverside.php?active_date=1&n="+indx;
  xhttp2.open("POST", c, true);
  xhttp2.send();
}

function deactiveUser(indx) {
  var xhttp2 = new XMLHttpRequest();
  c = "PHP/serverside.php?deactive_user=1&n="+indx;
  xhttp2.open("POST", c, true);
  xhttp2.send();
}

function activeUser(indx) {
  var xhttp2 = new XMLHttpRequest();
  c = "PHP/serverside.php?active_user=1&n="+indx;
  xhttp2.open("POST", c, true);
  xhttp2.send();
}

function addUserAdmin() {
  var xhttp2 = new XMLHttpRequest();
  xhttp2.onreadystatechange = function() {
    if (xhttp2.readyState == 4 && xhttp2.status == 200) {
	document.getElementById("showLog").innerHTML = xhttp2.responseText;
	document.getElementById("showLog").style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?add_users_func=1";
  xhttp2.open("POST", c, true);
  xhttp2.send();
}

function addUserJoin() {
  var xhttp2 = new XMLHttpRequest();
  xhttp2.onreadystatechange = function() {
    if (xhttp2.readyState == 4 && xhttp2.status == 200) {
	document.getElementById("showLog").innerHTML = xhttp2.responseText;
	document.getElementById("showLog").style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?add_users_func=2";
  xhttp2.open("POST", c, true);
  xhttp2.send();
}

function removeUser() {
  var xhttp2 = new XMLHttpRequest();
  xhttp2.onreadystatechange = function() {
    if (xhttp2.readyState == 4 && xhttp2.status == 200) {
	document.getElementById("showLog").innerHTML = xhttp2.responseText;
	document.getElementById("showLog").style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?rem_users_func=1";
  xhttp2.open("POST", c, true);
  xhttp2.send();
}

function addDate() {
  var xhttp2 = new XMLHttpRequest();
  xhttp2.onreadystatechange = function() {
    if (xhttp2.readyState == 4 && xhttp2.status == 200) {
	document.getElementById("showLog").innerHTML = xhttp2.responseText;
	document.getElementById("showLog").style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?add_date_func=1";
  xhttp2.open("POST", c, true);
  xhttp2.send();
}

function removeDate() {
  var xhttp2 = new XMLHttpRequest();
  xhttp2.onreadystatechange = function() {
    if (xhttp2.readyState == 4 && xhttp2.status == 200) {
	document.getElementById("showLog").innerHTML = xhttp2.responseText;
	document.getElementById("showLog").style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?rem_date_func=1";
  xhttp2.open("POST", c, true);
  xhttp2.send();
}

function listMySched() {
  var xhttp3 = new XMLHttpRequest();
  xhttp3.onreadystatechange = function() {
    if (xhttp3.readyState == 4 && xhttp3.status == 200) {
	document.getElementById("idListSched").innerHTML = xhttp3.responseText;
	document.getElementById("showListSched").style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?whois=1";
  xhttp3.open("POST", c, true);
  xhttp3.send();
}

function listSched() {
  var xhttp3 = new XMLHttpRequest();
  xhttp3.onreadystatechange = function() {
    if (xhttp3.readyState == 4 && xhttp3.status == 200) {
	document.getElementById("idSched").innerHTML = xhttp3.responseText;
	document.getElementById("showSched").style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?whois_side=1";
  xhttp3.open("POST", c, true);
  xhttp3.send();
}

function addNote() {
  var xhttp3 = new XMLHttpRequest();
  xhttp3.onreadystatechange = function() {
    if (xhttp3.readyState == 4 && xhttp3.status == 200) {
	document.getElementById("idNote").innerHTML = xhttp3.responseText;
	document.getElementById("showNotes").style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?add_note_func=1";
  xhttp3.open("POST", c, true);
  xhttp3.send();
}

function listNotes() {
  var xhttp4 = new XMLHttpRequest();
  xhttp4.onreadystatechange = function() {
    if (xhttp4.readyState == 4 && xhttp4.status == 200) {
	document.getElementById("idNotes").innerHTML = xhttp4.responseText;
	document.getElementById("showNotes").style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?listing_notes=1";
  xhttp4.open("POST", c, true);
  xhttp4.send();
}

function listSideNotes() {
  var xhttp4 = new XMLHttpRequest();
  xhttp4.onreadystatechange = function() {
    if (xhttp4.readyState == 4 && xhttp4.status == 200) {
	document.getElementById("idSideNote").innerHTML = xhttp4.responseText;
	document.getElementById("showSideNotes").style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?listing_side_notes=1";
  xhttp4.open("POST", c, true);
  xhttp4.send();
}

function readNote(m) {
  var xhttp4 = new XMLHttpRequest();
  xhttp4.onreadystatechange = function() {
    if (xhttp4.readyState == 4 && xhttp4.status == 200) {
	document.getElementById('idNote').innerHTML = xhttp4.responseText;
	document.getElementById('showNotes').style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?read_notes="+m;
  xhttp4.open("POST", c, true);
  xhttp4.send();
}

setInterval(function() {
	listSideNotes();
	callLogger();
}, 5500)