<?php session_start(); ?>
<html>
<title>WorkLoad - Collaborator</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>
<link rel="stylesheet" href="css/w3.css">
<script src="scripts.js"></script>
<script src="pipes.js"></script>

<?php
    require_once("PHP/serverside.php");
    require_once("PHP/startup.php");
    unset($_POST['password']);
    $d = date("j");
    $m = $pm = $am = date("m");
    $am++; $pm--;
    $Y = $aY = $pY = date("Y");
    if(isset($_POST['m'])) { $m = $_POST['m']; $am = $m + 1; $pm = $m - 1; }
    if(isset($_POST['y'])) { $Y = $_POST['y']; }
    if($am > 12) { $am = 1; $aY++; }
    if($pm < 1) { $pm = 12; $pY--; }
    if($m > 12) { $m = 1; $Y++; }
    if($m < 1) { $m = 12; $Y--; }
?>

</head>

<body style="margin-top:0;margin-bottom:0px;" onload="pipePage()">

<div id="showFullPage">
    <?php require_once("PHP/workload.php"); ?>
</div>

</body>
</html>