<?php
session_start();
	$conn = new mysqli("db5009558953.hosting-data.io:3306",'dbu322303','TYIsNerWasDr$1@','dbs8105296');
	if ($conn->connect_error) die($conn->error);
	function get_post($var) {
		return $conn->real_escape_string($_POST[$var]);
	}
	function get_get($conn, $var) {
		return $conn->real_escape_string($_POST[$var]);
	}
	echo '<form method="POST" action="adduser.php"><table style="z-index:2"><tr><td>Username</td><td>Password</td></tr>';
	echo '<tr><td><input name="username" type="textbox" required/></td><td><input type="password" name="password" required/></td></tr>';
	echo '<tr><td>Domain</td><td>Email</td></tr>';
	echo '<tr><td><input name="domain" type="url" placeholder="https://" required/></td><td><input type="textbox" name="email" placeholder="user@mail.org" required/></td></tr>';
	echo '<tr><td>First</td><td>Last</td></tr>';
	echo '<tr><td><input name="first" type="textbox" required/></td><td><input type="textbox" name="last" required/></td></tr>';
	echo '<tr><td>Middle</td><td>Zip Code</td></tr>';
	echo '<tr><td><input name="middle" type="textbox" required/></td><td><input type="textbox" name="zip" required/></td></tr>';
	echo '<tr><td>Area Code</td><td>Phone</td></tr>';
	echo '<tr><td><input name="areacode" type="textbox" required/></td><td><input type="textbox" name="phone" required/></td></tr>';
	echo '<tr><td style="text-align:right" colspan=2><button type="submit">Add User</button></form></td></tr>';
	echo '</table>';


	$query = 'SELECT * FROM customers;';
	$resultb = $conn->query($query);
	if (!$resultb) die("Database access failed: $conn->error");

	$rows = $resultb->num_rows;
	echo $rows . ' Customers<br/><br/>';
	for ($j = 0; $j < $rows; ++$j) {
		$resultb->data_seek($j);
		$row = $resultb->fetch_array(MYSQLI_NUM);

	echo	'<br>Domain:' . $row[1];
	echo	'<br>User:' . $row[2];
	echo	'<br>Password:********';
	echo	'<br>Sign up:' . $row[4];
	echo	'<br>Email:' . $row[5];
	echo	'<br><form action="newcust.php" method="POST">';
	echo	'<input type="hidden" value="' . $row[0] . '" name="indx"/>';
	echo	'<input type="hidden" value="yes" name="delete"/>';
	echo	'<button type="submit">DELETE</button></form>';
	}
	$conn->close();
?>