<?php 
	if (!isset($_SESSION))
		session_start(); 
	require_once("serverside.php");

    global $d;

	$d = date("d");
    if(isset($_POST['d'])) { $d = ($_POST['d']); }

    global $m;

	$m = date("m");
    if(isset($_POST['m'])) { $m = ($_POST['m']); }

    global $Y;
	
	$Y = date("Y");
    if(isset($_POST['y'])) { $Y = ($_POST['y']); }
    
    $ad = $d%cal_days_in_month(CAL_GREGORIAN,$m,$Y) + 1;
	$pd = $d%cal_days_in_month(CAL_GREGORIAN,$m,$Y) - 1;
    $am = $m%13 + 1; $pm = $m - 1;
    $aY = $Y + 1; $pY = $Y - 1;
 
	$txt = '<body onload="pipePage()">';
	$txt .= '<div class="w3-modal-content">';
	if ($d - 1 <= 0 && $pm <= 1) { $pd = cal_days_in_month(CAL_GREGORIAN,$pm,$pY); $pm = 12; $Y = $pY; }
	else if ($d - 1 <= 0) { $pd = cal_days_in_month(CAL_GREGORIAN,$m%13 + 1,$Y); }
	$dd0 = date_create("$Y-$pm-$pd");
	$txt .= "<h2><center><c method='POST' class='pipe' id='prevday' onclick='pipe(this)' target='idIncomingPage' ajax='PHP/day.php' query='m=" . date_format($dd0,"m") . '&y=' . date_format($dd0,"Y") . '&d=' . date_format($dd0,"d") . "'> &#8647; </c>"; 
	$txt .= '<span style="cursor:default">';
	$dto = date_create("$d-$m-$Y");
	$ddate = date_format($dto, "S");
	$mdate = date_format($dto, "M");
	$txt .= $mdate;
	$txt .= ' ' . $d . $ddate;
	$txt .= '</span>';
	if ($d + 1 > cal_days_in_month(CAL_GREGORIAN,$m%13 + 1,$Y) && $am > 12) { $ad = 1; $am = 1; $Y = $aY; }
	else if ($d + 1 > cal_days_in_month(CAL_GREGORIAN,$m%13 + 1,$Y)) { $ad = 1; $am = $m + 1; }

	$dd1 = date_create("$Y-$am-$ad");
	$txt .= "<c method='POST' id='nextday' onclick='pipe(this)' target='idIncomingPage' ajax='PHP/day.php' query='m=" . date_format($dd1,"m") . '&y=' . date_format($dd1,"Y") . '&d=' . date_format($dd1,"d") . "'> &#8649; </c>"; 
	$txt .= '</h2></header>';
	echo $txt;
	echo '<form method="POST">';
	echo '<table style="text-align:top" border=1 width="50%" cellpadding="3"><tr>';
	echo '<td style="cursor:default">Start Time</td>';
	echo '<td style="cursor:default" colspan=2>Date of Event\'s End</td><td colspan=2>Whom? <input type="textbox" name="sched_whom"></td><td></td><td></td></tr>';
	echo '<tr><td style="text-align:center;border-top:1px black dotted;border-left:1px black dotted"><input type="time" value="09:00" step="900" name="timea"/></td>';
	echo "<td style=\"border-top:1px dotted black;\" colspan=2><input type=\"date\" style=\"width:225\" min=\"1\" name=\"length\" value=\"$Y-$m-$d\" width=\"5\" required/></td>";
	echo '<td style="text-align:left;border-top:1px dotted black;border-right:1px dashed black;border-bottom:1px dotted black;cursor:default"><input type="checkbox" name="singular"/> For Self</td>';
	echo '<td style="text-align:left;border-top:1px black dotted;border-right:1px dotted black;text-align:center;cursor:default"><input type="checkbox" name="vaca"/> Vacation</td>';
	echo '<td style="font-size:32px;" rowspan="3"><button onclick="addDate()" type="submit" style="border:0px;color:green;background-color:white;">+</button></td>';
	echo '<td style="font-size:32px;" rowspan="3"><span style="border:0px;color:black;background-color:white;cursor:pointer;" onclick="callIndex();">x</span></td></tr>';
	echo '<td style="vertical-align:bottom;border-left:1px black dotted;cursor:default">End Time</td>';
	echo '<td style="border-bottom:1px black dotted;align:top" colspan=2><textarea style="height:50;width:225" name="dtls" value="Event" required>Event Details</textarea></td>';
	echo '<td style="border-left:1px black dotted;border-right:1px black solid;background-color:lightblue;padding-left:10px" colspan=2><span style="cursor:default;font-size:12px;">Enter Start & End times, choose different length if extends beyond one<br/>If for leave, set Vacation and End Date</span></td></tr>';
	echo '<tr><td style="text-align:center;border-left:1px black dotted;border-bottom:1px black dotted;border-right:0px black none;"><input type="time" value="05:00" name="timez"></td>';
	echo '<td style="border-bottom:1px black dotted;text-align:center"><input type="checkbox" name="perm"/> Permanent</td>';
	echo '<td style="text-align:center;color:red;border-bottom:1px dotted black"> <input type="checkbox" name="all"/> All Users</form></td>';
	echo '<td style="border-bottom:1px black solid;border-right:1px black solid;border-left:1px black dashed;background-color:lightblue;padding-left:10px;font-size:12px;" colspan=2><span style="color:red;cursor:default;">All Users</span> will commit this to groups lower than you</td>';
	echo '</tr></table>';
	echo '</div>';

	$txt = '';
	$txt .= '<footer class="w3-container" style="background:' . $profile->background . '">';
	$txt .= '<p>Copyright &copy; - ' . date("Y") . '</p>';
	$txt .= '</footer></div>';
	echo $txt;
?>

<script>
document.addEventListener("DOMContentLoaded", function() {
	pipePage();
});
</script>
