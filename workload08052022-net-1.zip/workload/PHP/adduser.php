<?php
    require_once("serverside.php");

    $try = new Logger();

    $begin = 'BId74i'; $end = 'sDI0j';
    $pastok = md5("$begin" . $_POST['password'] . "$end");
    //$domaintok = md5("$begin" . $_SERVER['HTTP_ORIGIN'] . "end");
    $dbquery = 'SELECT USER FROM customers WHERE USER = "' . $_POST['username'] . '";';
    $results = $conn->query($dbquery) or die("Lookup Error &lt;User (1)&gt;: " . $conn->error . "<br/><br/>");
    
    if ($results->num_rows > 0) {
        echo "User Exists";
        return;
    }

    $dbquery = "INSERT INTO customers VALUES";
    $dbquery .= '(NULL,"' . $_POST['domain'] . '","' . $_POST['username'] . '","' . $pastok . '",NULL,"' . $_POST['email'] . '","' . $_POST['first'] . '","' . $_POST['last'] . '","' . $_POST['middle'] . '","' . $_POST['areacode'] . '","' . $_POST['phone'] . '","' . $_POST['zip'] . '")';

    $results = $conn->query($dbquery) or die("Lookup Error &lt;User (1)&gt;: " . $conn->error . "<br/><br/>");
    
    if ($results) {
        $try->result = "Success";
        $try->attr = "Add User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
        $try->user = $_POST['username']; $try->utoken = ""; $try->group = 100000;
        setcookie("userin",$_POST['username']);
    }
    else { 
        throwError("Add User Denied"); $try->result = "Fail";
        $try->attr = "Add User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
        $try->user = $_POST['username']; $try->utoken = ""; $try->group = 100000;
        unset($_COOKIE['userin']);
    }
    unset($_POST['password']);
    Logger::logAll($try, $conn);
	header("Location: https://workload.bitpxr.com/");
?>