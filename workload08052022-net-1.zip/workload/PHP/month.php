<?php
	require_once("serverside.php");
	require_once("../headers/head.php");

	if ($m == 10)
		$txt = '<table style="background:transparent;z-index:1;text-align:center;position:relative;width:850;"><tr><td><span style="color:white;">BOO!</span></td>';
	else if ($m == 12)
		$txt = '<table style="background:transparent;z-index:1;text-align:center;position:relative;width:850;"><tr><td><span style="color:white;">HO HO HO!</span></td>';
	else $txt = '<table style="background:transparent;z-index:1;text-align:center;position:relative;width:850;"><tr><td>&nbsp;</td>';

	$j = 0;
	while ($j < 7) {
		$txt .= '<td class="w3-animate-top" style="border:3px solid darkblue;padding:3;cursor:default;border-color:darkblue;background-color:lightblue;">' . jddayofweek($j,2) . '</td>';
		$j++;
	}
	echo $m . " $Y";
	$ddate = date_create("1-$m-$Y");
	$day = date_format($ddate,"N");

	// Day = month, day
	// Week = Week
	// Month = month, year

	$pY = $Y;
	if ($pm == 0) { $pm = 12; $pY = $Y - 1; }
	$xv = cal_days_in_month(CAL_GREGORIAN,date_format($pm,"m"),$pY);

	$txt .= '</tr><tr>';

	$i = $xv - $day + 1;
	$n = date_create("$m-$d-$Y");
	$txt .= '<td width=200 style="cursor:default"><h3>First of Month</h3></td>';
	$h = 0;
	while ($i++ < $xv) {
		$dd = date("d", $i);
		$txt .= "<td id='date0$j' target='idIncomingPage' method='POST' ajax='PHP/day.php' onclick='pipe(this)' style='width:75px;height:75px;cursor:pointer;border:1px black solid' query='m=" . date_format($n,"m") . "&y=" . date_format($n,"m") . "&d=" . date_format($n,"m") . "'><h5>$i</h5></td>$tag";
		
		$h++;
	}

	$xv = cal_days_in_month(CAL_GREGORIAN,$m,$Y);

	$h++;	
	$t = null;
	for ($j = 1;$j <= $xv; $j++) {
		if (($h)%7 == 0 && $j < $xv) {
			$h = 0;
			$x = $j;
			$t = date_create("$x-$m-$Y");
			$tag = '</tr><tr><td class="w3-animate-left" style="cursor:default"><h3>Week of ' . ($x);
			$tag .= date_format($t,"S") . '</h3></td>';
			$tiger = '</tr><tr><td style="width:75px;height:75px"><h3>&nbsp;</h3></td>';
		}
		else {
			$tag = '';
			$tiger = '';
		}
		if ($j != date("j") || $m != date("m") || $Y != date("Y")) {
			$txt .= "<td id='date1$j' target='idIncomingPage' method='POST' ajax='PHP/day.php' onclick='pipe(this)' query='" . "m=" . date_format($pm,"m") . "&d=" . date_format($pm,"d") . "&y=" . date_format($pm,"Y") . "' style='width:75px;height:75px;cursor:pointer;border:1px black solid'><h3>$j</h3></td>$tag";
		}
		else {
			$txt .= "<td id='date1$j' target='idIncomingPage' method='POST' ajax='PHP/day.php' onclick='pipe(this)' query='" . "m=" . date_format($am,"m") . "&d=" . date_format($am,"d") . "&y=" . date_format($am,"Y") . "' class='w3-animate-zoom w3-text-shadow w3-xxxlarge' style='color:red;cursor:pointer;border:3px green dotted;'>$j</td>$tag";
		}
		$h++;
	}

	$j = 1;
	$x = 1;
	$aY = $Y;
	if ($m + 1 == 13) { $am = 1; $aY = $Y + 1; }
	while ((6 + $h)%7) {
      	$n = date_create("$j-$m-$aY");
		$dd = date("j", $j);
		$txt .= "<td id='date2$j' query='" . "m=" . date_format($n,"m") . "&d=" . date_format($n,"d") . "&y=" . date_format($n,"Y") . "' target='idIncomingPage' method='POST' ajax='PHP/day.php' onclick='pipe(this)' style='width:75px;height:75px;cursor:pointer;border:1px black solid'>$j</td>";
		$j++;
		$h++;
	}

	$txt .= '</tr></table>';
	echo $txt;
	

?>