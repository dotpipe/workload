<?php
require_once("../PHP/startup.php");

$URL = "showMo";
$d = date("d");
$ad = $d + 1;
$pd = $d - 1;
$m = $pm = $am = date("m");
if(! isset($Y)) { $Y = date("Y"); }
if(isset($_GET['m'])) { $m = $_GET['m']; }
if(isset($_GET['y'])) { $Y = $_GET['y']; }
if($_GET['u']) { $URL = $_GET['u']; }
$am = date_create("$d-$m-$Y"); $pm = date_create("$d-$m-$Y");

	$txt =  '<div class="w3-modal-content">';
	$txt .= '<header class="w3-container">';
	$txt .= '<h2><center>';
	$pY = $Y;
	if ($m - 1 == 0) { $pm = date_create("12-31-".($Y-1)); }
	$txt .= '<span target="idIncomingPage" clear onclick="pipe(this)" ajax="../PHP/month.php" query="' . "m=" . date_format($pm,"m") . "&d=" . date_format($pm,"d") . "&y=" . date_format($pm,"Y") . '" style="cursor:default;"> &#8647;</span></center>';

	$dto = date_create("1-$m-$Y");
	$ddate = date_format($dto, "M/Y");
	$txt .= '<span style="cursor:default"> Schedule for ' . $ddate;

	if ($m + 1 == 13) { $am = date_create("1-1-".($Y+1)); }
	$txt .= '</span><span target="idIncomingPage" clear ajax="../PHP/month.php" onclick="pipe(this)" query="' . "m=" . date_format($am,"m") . "&d=" . date_format($am,"d") . "&y=" . date_format($am,"Y") . '" style="cursor:default"> &#8649;</span></center>';
	$txt .= '</h2></header>';
	echo $txt; $txt = '';
	$txt = '<div class="w3-container">';
	$txt .= '<p id="' . $URL . '"></p>';
	$txt .= '</div>';
	$txt .= '<footer class="w3-container">';
	$txt .= '<p>Copyright &copy; - ' . date("Y") . '</p>';
	$txt .= '</footer></div>';
	echo $txt;
?>