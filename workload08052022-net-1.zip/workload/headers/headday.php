<?php
require_once("../PHP/startup.php");
$URL = "showMo";
$d = date("d");
$m = date("m");
if(! isset($Y)) { $Y = date("Y"); }
if(isset($_POST['m'])) { $m = $_POST['m']; }
if(isset($_POST['y'])) { $Y = $_POST['y']; }
if($_POST['d']) { $d = $_POST['d']; }
if($_POST['u']) { $URL = $_POST['u']; }
$ad = $d + 1; $pd = $d - 1;
$am2 = $m; $pm2 = $m;
$aY = $Y; $pY = $Y;
if ($ad > cal_days_in_month(CAL_GREGORIAN,$m,$Y) && $m == 12) { $d = 1; $am2 = 1; $Y = $Y + 1; }
if ($ad > cal_days_in_month(CAL_GREGORIAN,$m,$Y) && $m < 12) { $d = 1; $m = $m + 1; $Y--; }
if ($pd == 0 && $m == 1) { $m = 12; $Y = $Y - 1; $pd = cal_days_in_month(CAL_GREGORIAN,$am2,$Y); }
if ($pd == 0 && $m > 1) { $m = $m - 1; $pd = cal_days_in_month(CAL_GREGORIAN,$pm2,$Y); }
	$Y = $aY;
	$txv = cal_days_in_month(CAL_GREGORIAN,$m,$Y);
	echo '<div id="pages">';
	$txt =  '<div class="w3-modal-content">';
	$txt .= '<header class="w3-container" style="background:' . $profile->background . '">';
	$txt .= "<h2><center><span id='prevday' onclick='pipe(this)' target='pages' ajax='headers/headday.php' query='m=$pm2&y=$Y&d=$pd'> &#8647; </span>"; 
	$txt .= '<span style="cursor:default">';
	$dto = date_create("$d-$m-$Y");
	$ddate = date_format($dto, "S");
	$mdate = date_format($dto, "M");
	$txt .= $mdate;
	$txt .= ' ' . $d . $ddate;
	$txt .= '</span>';
	$txt .= "<span id='nextday' onclick='pipe(this)' target='pages' ajax='headers/headday.php' query='m=$pm2&y=$Y&d=$ad'> &#8649; </span>"; 
	$txt .= '</h2></header>';
	echo $txt; $txt = '';
	$txt = '<div class="w3-container">';
	$txt .= '<p id="' . $URL . '"></p>';
	$txt .= '</div>';
	echo $txt;
	$txt = '';
	$txt .= '<footer class="w3-container" style="background:' . $profile->background . '">';
	$txt .= '<p>Copyright &copy; - ' . date("Y") . '</p>';
	$txt .= '</footer></div>';
	echo $txt;
	require_once("../PHP/day.php");
	echo '</div>';
	

?>