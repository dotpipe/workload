<?php

	$temp = '<table style="width:125;cursor:pointer;border:5px teal solid;font-size:20px;background-color:' . $profile->background . '">';
	$temp .= '<tr><td style="padding:10px;border:5px teal solid;"><span id="join" target="idIncomingPage" method="POST" ajax="PHP/newcust.php" onclick="pipe(this)">Sign Up!</span><br/></td></tr>';
	$temp .= '<tr><td style="padding:10px;border:5px teal solid;"><span id="cal" target="idIncomingPage" method="POST" ajax="PHP/month.php" onclick="pipe(this)">Calendar</span><br/></td></tr>';
	$temp .= '<tr><td style="padding:10px;border:5px teal solid;"><span id="sched" target="idIncomingPage" method="POST" ajax="PHP/sched.php" onclick="pipe(this)">Schedule</span><br/></td></tr>';
	$temp .= '<tr><td style="padding:10px;border:5px teal solid;"><span id="notes" target="idIncomingPage" method="POST" ajax="PHP/notes.php" onclick="pipe(this)">>Notebox</span><br/></td></tr>';
	if (isset($_COOKIE['userin']))
		$temp .= '<tr><td style="padding:10px;border:5px teal solid;"><span id="headuser" target="idIncomingPage" method="POST" ajax="headers/headuser.php" onclick="pipe(this)">User Config</span><br/></td></tr>';
	$temp .= '<tr><td style="padding:10px;border:5px teal solid;"><span id="login" target="idIncomingPage" method="POST" ajax="PHP/login.php" onclick="pipe(this)">Login</span><br/></td></tr>';
	$temp .= '</table>';
	echo $temp;
?> 