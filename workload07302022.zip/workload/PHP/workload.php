<?php
session_start(); ?>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="../css/w3.css">
  
<?php
	require_once("serverside.php");

$d = date("j");
$m = $pm = $am = date("m");
$am++; $pm--;
$Y = $aY = $pY = date("Y");
if(isset($_GET['m'])) { $m = $_GET['m']; $am = $m + 1; $pm = $m - 1; }
if(isset($_GET['y'])) { $Y = $_GET['y']; }
if(isset($_GET['dif']) && $_GET['dif'] == 1) { $m = $_GET['dm']; $Y = $_GET['dy']; $GLOBALS['dif'] = 0; }
if($am > 12) { $am = 1; $aY++; }
if($pm < 1) { $pm = 12; $pY--; }
if($m > 12) { $m = 1; $Y++; }
if($m < 1) { $m = 12; $Y--; }

?>
</head>

<body style="margin:10px;background-color:white" onload='callPHPHead("month",<? echo $m . "," . $Y . "," . $d; ?>)'>
<table style="width:100%;border:5px black solid">
<tr>
<td style="vertical-align:top;width:10%">

<div id="idLogger">
<p id="showLog"></p>
</div>

</td>
<td style="vertical-align:top;text-align:center;width:800" rowspan=3>

<div id="idIncomingPage">
<p id="showIncPage"></p>
</div>


</td>
<td style="vertical-align:top;" rowspan=2>
<table style="padding-left:15px;width:225">
<tr><td style="vertical-align:top;">
<?php if (isset($_COOKIE['userin']))
	echo 'Logged In As: ' . $_COOKIE['userin'];
   else echo 'Logged Out';
	echo '<h3 style="text-decoration:underline">Quick Links</h3></td></tr>';
   $sm = date("m");
   $qY = date("Y");
   for ($x=0;$x<6;$x++) {
	echo '<tr><td>';
	if($sm > 12) { $sm = 1; $qY++; }
	else { $sm = (date("m") + $x)%12+1; }
	if ($sm <= 3)
		$q1 = 1;
	else if ($sm <= 6)
		$q1 = 2;
	else if ($sm <= 9)
		$q1 = 3;
	else
		$q1 = 4;
	$dated = date_create("1-$sm-$qY");
	$datedd = date_format($dated, "M/Y");
	echo '<span onclick=' . 'callPHPHead("month",' . $sm . ',' . $qY . ',1)>Q' . $q1 . ' ' . $datedd . '</span></td></tr>';
	$sm++;
   }
?>
<br/>
<?php echo '<tr><td style="vertical-align:top;"><span style="padding-left:2px;padding-right:2px;background:transparent;border:1px black solid" onclick=' . 'callPHPHead("month",' . date("m") . ',' . date("Y") . ',1)> Current Month </span></td></tr>'; ?>
<tr><td style="vertical-align:top;"><form method="POST"><input type="textbox" style="width:60" name="lvl"> <button style="background:transparent;border:1px black solid" type="submit"> Switch Level</button></form>
<tr><td style="vertical-align:top;"><h3 style="text-decoration:underline">My Schedule</h3></td></tr>
<tr><td style="vertical-align:top;">
<div id="idListSched">
<p id="showListSched"></p>
</div>
</td></tr>
<tr><td style="vertical-align:top;"><h3 style="text-decoration:underline">Notes</h3></td></tr>
<tr><td style="vertical-align:top;">
<div id="idSideNotes">
<p id="showSideNotes"></p>
</div>
</td></tr>
</table>
</td>
</tr>

<tr><td style="vertical-align:top;text-align:center">
<?php
include("../html/menu.php");
?>
</td></tr>
</body>