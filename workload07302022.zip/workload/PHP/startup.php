<?php
require_once("serverside.php");

	class Profiles {
		public $background;
		public $textcolor;
	}

	$profile = new Profiles();

	if(isset($_POST['color'])) { $profile->background = $_POST['color']; } //
	else $profile->background = "white";
	if(isset($_POST['usr'])) { $users->uname = $_POST['usr']; } //
	if(isset($_POST['pw'])) { $users->password = $_POST['pw']; } //
	if(isset($_POST['moduser'])) { $users->moduser = $_POST['moduser']; } //
	if(isset($_POST['modgrp'])) { $users->modgrp = $_POST['modgrp']; } //
	if(isset($_POST['grp'])) { $users->usrlvl = $users->usrgrp = $_POST['grp']; } //
	if(isset($_POST['email'])) { $users->email = $_POST['email']; } //
	if(isset($_POST['singular'])) { $dates->singular = $_POST['singular']; } //
	if(isset($_POST['y'])) { $dates->year = $_POST['y']; } //
	if(isset($_POST['m'])) { $dates->month = $_POST['m']; } //
	if(isset($_POST['d'])) { $dates->day = $_POST['d']; } //
	if(isset($_POST['dy'])) { $dates->year = $_POST['dy']; } //
	if(isset($_POST['dm'])) { $dates->month = $_POST['dm']; } //
	if(isset($_POST['vacation'])) { $dates->vacation = $_POST['vacation']; } //
	if(isset($_POST['perm'])) { $dates->perm = $_POST['perm']; } //
	if(isset($_POST['length'])) { $dates->length = $_POST['length']; } //
	if(isset($_POST['dtls'])) { $dates->dtls = $_POST['dtls']; } //
	if(isset($_POST['all'])) { $dates->all = $_POST['all']; } //
	if(isset($_POST['password'])) { $logins->password = $_POST['password']; } //
	if(isset($_POST['inusr'])) { $users->uname = $_POST['inusr']; } //
	if(isset($_POST['idx'])) { $users->indx = $_POST['idx']; } //
	if(isset($_POST['is_admin'])) { $users->adm = $_POST['is_admin']; } //
	if(isset($_POST['set_admin'])) { $users->setadm = $_POST['set_admin']; } //
	if(isset($_POST['recp'])) { $notes->to = $_POST['recp']; } //
	if(isset($_POST['dtls'])) { $users->desc = $_POST['dtls']; } //
	if(isset($_POST['begin'])) { $dates->begin = $_POST['begin']; } //
	if(isset($_SERVER['HTTP_ORIGIN'])) {
		$domaintok = md5("$begin" . $_SERVER['HTTP_ORIGIN'] . "$end");
		$users->utoken = $domaintok;
	}
?>