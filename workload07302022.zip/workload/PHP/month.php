<?php
	require_once("serverside.php");

$d = date("j");
$m = $pm = $am = date("m");
if(! isset($Y)) { $Y = date("Y"); }
if(isset($_GET['m'])) { $m = $_GET['m']; }
if(isset($_GET['y'])) { $Y = $_GET['y']; }
$am = $m + 1; $pm = $m - 1;

	if ($m == 10)
		$txt = '<table style="background:transparent;z-index:1;text-align:center;position:relative;width:850;"><tr><td><span style="color:white;">BOO!</span></td>';
	else if ($m == 12)
		$txt = '<table style="background:transparent;z-index:1;text-align:center;position:relative;width:850;"><tr><td><span style="color:white;">HO HO HO!</span></td>';
	else $txt = '<table style="background:transparent;z-index:1;text-align:center;position:relative;width:850;"><tr><td>&nbsp;</td>';

	$j = 0;
	while ($j < 7) {
		$txt .= '<td class="w3-animate-top" style="border:3px solid darkblue;padding:3;cursor:default;border-color:darkblue;background-color:lightblue;">' . jddayofweek($j,2) . '</td>';
		$j++;
	}

	$ddate = date_create("1-$m-$Y");
	$day = date_format($ddate,"N");

	// Day = month, day
	// Week = Week
	// Month = month, year

	$pY = $Y;
	if ($pm == 0) { $pm = 12; $pY = $Y - 1; }
	$xv = cal_days_in_month(CAL_GREGORIAN,$pm,$pY);

	$txt .= '</tr><tr>';

	$i = $xv - $day + 1;
	$txt .= '<td width=200 style="cursor:default"><h3>First of Month</h3></td>';
	$h = 0;
	while ($i++ < $xv) {
			$txt .= "<td id='date0$j' target='idIncomingPage' method='POST' ajax='PHP/day.php' onclick='pipe(this)' style='width:75px;height:75px;cursor:pointer;border:1px black solid' onclick='pipe(this)'><h3>$j</h3></td>$tag";
		
		$h++;
	}

	$xv = cal_days_in_month(CAL_GREGORIAN,$m,$Y);

	$h++;	

	for ($j = 1;$j <= $xv; $j++) {
		if (($h)%7 == 0 && $j < $xv) {
			$h = 0;
			$x = $j;
			$t = date_create("$x-$m-$Y");
			$tag = '</tr><tr><td class="w3-animate-left" style="cursor:default"><h3>Week of ' . ($x);
			$tag .= date_format($t,"S") . '</h3></td>';
			$tiger = '</tr><tr><td style="width:75px;height:75px"><h3>&nbsp;</h3></td>';
		}
		else {
			$tag = '';
			$tiger = '';
		}
		if ($j != date("j") || $m != date("m") || $Y != date("Y")) {
			$txt .= "<td id='date1$j' target='idIncomingPage' method='POST' ajax='PHP/day.php' onclick='pipe(this)' style='width:75px;height:75px;cursor:pointer;border:1px black solid' onclick='pipe(this)'><h3>$j</h3></td>$tag";
		}
		else {
			$txt .= "<td id='date1$j' target='idIncomingPage' method='POST' ajax='PHP/day.php' onclick='pipe(this)' class='w3-animate-zoom w3-text-shadow w3-xxxlarge' style='color:red;cursor:pointer;border:3px green dotted;' onclick='pipe(this)'>$j</td>$tag";
		}
		$h++;
	}


	$x = 1;
	$aY = $Y;
	if ($am == 13) { $am = 1; $aY = $Y + 1; }
	while ((6 + $h)%7) {
		$txt .= "<td id='date2$j' style='width:75px;height:75px;cursor:pointer' onclick='pipe(this)'>$j</td>";
		$h++;
	}

	$txt .= '</tr></table>';
	echo $txt;
	

?>