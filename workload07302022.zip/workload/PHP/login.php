<?php
	require_once("serverside.php");


	$URL = "showIncPage";
	global $dy;
	$dy = date("j");
	global $mo;
	$mo = date("m");
	global $Yr;
	$Yr = date("Y");
	if(! isset($Yr)) { $Yr = date("Y"); }
	if(isset($_GET['m'])) { $mo = $_GET['m']; }
	if(isset($_GET['y'])) { $Yr = $_GET['y']; }
	if(! isset($_GET['d'])) { $dy = 1; }

	echo '<form method="POST" action="index.php">';
	echo '<input type="hidden" name="start_login" value="on"/>';
	echo '<table style="text-align:top" border=1 width="50%" cellpadding="3"  ><tr>';
	echo '<td style="cursor:default">Username</td>';
	echo '<td style="cursor:default">Password</td>';
	echo '<tr><input type="hidden" value="1" name="login_credentials">';
	echo '<tr><td><input name="inusr" type="text" required/></td><td><input name="password" type="password" required/>';
	echo '<td><button style="text-align:center;border:1px solid black" type="submit">'; //' . 'callPHPHead("login",' . $mo . ',' . $Yr . ',' . $dy . ')>';
	echo 'Login</button></td><td><button style="text-align:center;border:1px solid black" onclick=' . 'callPHPHead("month",' . $mo . ',' . $Yr . ',' . $dy . ')>';
	echo 'Cancel</button></form></td></tr>';
	echo '</table>';

?>