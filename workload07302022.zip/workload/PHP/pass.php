<?php
	require_once("serverside.php");

	$URL = "showMo";
	global $dy;
	$dy = date(j);
	global $mo;
	$mo = date(m);
	global $Yr;
	$Yr = date(Y);
	if(! isset($Yr)) { $Yr = date(Y); }
	if(isset($_GET['m'])) { $mo = $_GET['m']; }
	if(isset($_GET['y'])) { $Yr = $_GET['y']; }
	if(! isset($_GET['d'])) { $dy = 1; }

	echo '<form method="POST">';
	echo '<input type="hidden" name="modify_password" value="on"/>';
	echo '<table style="text-align:top" width="50%" cellpadding="3"><tr>';
	echo '<td style="cursor:default">Old Password</td>';
	echo '<td style="cursor:default">New Password</td>';
	echo '<td style="cursor:default">Repeat New Password</td></tr>';
	echo '<input type="hidden" value="1" name="login_change_password">';
	echo '<tr><td><input name="old_passw" type="password" required/></td><td><input name="newpw" type="password" required/></td>';
	echo '<td align=center><input name="repw" type="password" required/></td>';
	echo '<td><button style="text-align:center;border:1px solid black;font-size:12px;" type="submit">';
	echo 'Change Password</button></td><td><button style="text-align:center;border:1px solid black" onclick=' . 'callPHPHead("month",' . $mo . ',' . $Yr . ',' . $dy . ')>';
	echo 'Cancel</button></form></td></tr>';
	echo '</tr></table>';

?>