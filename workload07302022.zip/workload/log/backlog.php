<?php
	require("../PHP/serverside.php");
	//require("../PHP/startup.php");
	$logconn = new mysqli('db5009558953.hosting-data.io:3306','dbu322303','TYIsNerWasDr$1@','dbs8105296');
	if ($logconn->connect_error) die($logconn->error);
	$temp = '';
	$result = array();
	if ($users->adm == "on") {
		$dbquery = 'SELECT * FROM logdb WHERE GROUP_NO >= "' . $users->usrgrp . '"';
		$result = $logconn->query($dbquery);
		if (!$result) echo "Log failure: $query<br>" .
			$logconn->error . "<br/><br/>";
		else reset($_GET);
		$rows = $result->num_rows;
		echo '<table style="border:1px solid black;width:200">';
		echo '<tr><td style="border-bottom:1px black dotted;font-size:12;background:tan">Error Log</td></tr>';
		for ($x = $rows ; $x >= $rows - 5 ; $x--) {
			$result->data_seek($x);
			$client = $result->fetch_array(MYSQLI_NUM);
			$temp .='<tr>';
			if (in_array("Success",$client)) {
				$temp .= '<td style="border-bottom:1px black dotted;font-size:12;';
				$temp .= 'background-color:darkgreen">';
				$temp .= $client[1] . ": " . $client[2];
				$temp .= '</td>';
			}
			else if (in_array("Fail",$client)) {
				$temp .= '<td style="border-bottom:1px black dotted;font-size:12;';
				$temp .= 'background-color:red">';
				$temp .= $client[1] . ": " . $client[2];
				$temp .= '</td>';
			}
			else {
				$temp .= '<td style="border-bottom:1px black dotted;font-size:12;">';
				$temp .= $client[1] . ": " . $client[2];
				$temp .= '</td>';
			}
			$temp .= '</tr>';
		}
		$temp .= '</table>';
		echo $temp;
	}
	else {
		$result = '';
		$temp = '';
		$dbquery = 'SELECT * FROM logdb WHERE GROUP_NO >= "' . $users->usrgrp . '"';
		$result = $logconn->query($dbquery);
		if (!$result) echo "Log failure: " .
			$logconn->error . "<br/><br/>";
		else reset($_GET);
		$rows = $result->num_rows;
		echo '<table style="border:1px solid black;width:200">';
		echo '<tr><td style="border-bottom:1px black dotted;font-size:12;background:tan">Error Log</td></tr>';
		$x = 0;
		for ($x = $rows - 1 ; $x > ($rows - 6)%($rows+1); $x--) {
			$result->data_seek($x);
			$client = $result->fetch_array(MYSQLI_NUM);
			$temp .='<tr>';
			if (in_array("Success",$client)) {
				$temp .= '<td style="border-bottom:1px black dotted;font-size:12;';
				$temp .= 'background-color:darkgreen">';
				$temp .= $client[1] . ": " . $client[2] . " " . $client[7];
				$temp .= '</td>';
				if ($client[2] == "Login")
					setcookie("userin",$client[7]);
			}
			else if (in_array("Fail",$client)) {
				$temp .= '<td style="border-bottom:1px black dotted;font-size:12;';
				$temp .= 'background-color:red">';
				$temp .= $client[1] . ": " . $client[2] . " " . $client[7];
				$temp .= '</td>';
			}
			else {
				$temp .= '<td style="border-bottom:1px black dotted;font-size:12;">';
				$temp .= $client[1] . ": " . $client[2] . " " . $client[7];
				$temp .= '</td>';
			}
			$temp .= '</tr>';
		}
		$temp .= '</table>';
		echo $temp;
	}
	$logconn->close();
?>