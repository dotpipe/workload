<?php
require_once("../PHP/startup.php");
$URL = "showMo";
$d = date("j");
$m = date("m");
if(! isset($Y)) { $Y = date("Y"); }
if(isset($_GET['m'])) { $m = $_GET['m']; }
if(isset($_GET['y'])) { $Y = $_GET['y']; }
if(isset($_GET['d'])) { $d = $_GET['d']; }
if(isset($_GET['u'])) { $URL = $_GET['u']; }
$ad = $d + 1; $pd = $d - 1;
$am2 = $m; $pm2 = $m;
$aY = $Y; $pY = $Y;
if ($ad > cal_days_in_month(CAL_GREGORIAN,$m,$Y) && $m == 12) { $ad = 1; $am2 = 1; $aY = $Y + 1; }
if ($ad > cal_days_in_month(CAL_GREGORIAN,$m,$Y) && $m < 12) { $ad = 1; $am2 = $m + 1; }
if ($pd == 0 && $m == 1) { $pm2 = 12; $pY = $Y - 1; $pd = cal_days_in_month(CAL_GREGORIAN,$pm2,$pY); }
if ($pd == 0 && $m > 1) { $pm2 = $m - 1; $pd = cal_days_in_month(CAL_GREGORIAN,$pm2,$Y); }

	$txv = cal_days_in_month(CAL_GREGORIAN,$m,$Y);
	$txt =  '<div class="w3-modal-content">';
	$txt .= '<header class="w3-container" style="background:' . $profile->background . '">';
	$txt .= '<h2><center>';
	$txt .= '<span style="cursor:default">';
	$txt .= 'Schedule';
	$txt .= '</span></center>';
	$txt .= '</h2></header>';
	echo $txt; $txt = '';
	$txt = '<div class="w3-container">';
	$txt .= '<p id="' . $URL . '"></p>';
	$txt .= '</div>';
	echo $txt; $txt = '';
	$txt .= '<footer class="w3-container" style="background:' . $profile->background . '">';
	$txt .= '<p>Copyright - ' . date("Y") . '</p>';
	$txt .= '</footer></div>';
	echo $txt;
?>