<?php
session_start();
	$conn = new mysqli("db5009558953.hosting-data.io:3306",'dbu322303','RTYfGhVbN!3$','dbs8105296');
	if ($conn->connect_error) die($conn->error);
	function get_post($conn, $var) {
		return $conn->real_escape_string($_POST[$var]);
	}
	function get_get($conn, $var) {
		return $conn->real_escape_string($_GET[$var]);
	}
	echo '<form method="POST" action="newcust.php"><table style="z-index:2"><tr><td>Username</td><td>Password</td></tr>';
	echo '<tr><td><input name="username" type="textbox" required/></td><td><input type="password" name="password" required/></td></tr>';
	echo '<tr><td>Domain</td><td>Email</td></tr>';
	echo '<tr><td><input name="domain" type="url" placeholder="http://" required/></td><td><input type="textbox" name="email" placeholder="user@mail.org" required/></td></tr>';
	echo '<tr><td>First</td><td>Last</td></tr>';
	echo '<tr><td><input name="first" type="textbox" required/></td><td><input type="textbox" name="last" required/></td></tr>';
	echo '<tr><td>Middle</td><td>Zip Code</td></tr>';
	echo '<tr><td><input name="middle" type="textbox" required/></td><td><input type="textbox" name="zip" required/></td></tr>';
	echo '<tr><td>Area Code</td><td>Phone</td></tr>';
	echo '<tr><td><input name="areacode" type="textbox" required/></td><td><input type="textbox" name="phone" required/></td></tr>';
	echo '<tr><td style="text-align:right" colspan=2><button type="submit">Add User</button></form></td></tr>';
	echo '</table>';

	if (isset($_GET['delete']) &&
		isset($_GET['indx'])) { 
		$indx = get_get($conn, 'indx');
		$query = 'DELETE FROM customers WHERE ID = "' . $indx . '";';
		$result = $conn->query($query);
		if (!$result) echo "DELETE failed: $query<br>" .
			$conn->error . "<br/><br/>";
	}

	if (isset($_POST['domain']) &&
		isset($_POST['username']) &&
		isset($_POST['password']))
	{
		$domain = get_post($conn, 'domain');
		$user = get_post($conn, 'username');
		$pass = get_post($conn, 'password');
		$email = get_post($conn, 'email');
		$first = get_post($conn, 'first');
		$last = get_post($conn, 'last');
		$middle = get_post($conn, 'middle');
		$zip = get_post($conn, 'zip');
		$areacode = get_post($conn, 'areacode');
		$phone = get_post($conn, 'phone');
		$query = "SELECT * FROM customers;";
		$begin = 'BId74i'; $end = 'sDI0j';
		$domaintok = $begin . $domain . $end;
		$passwtok = $begin . $pass . $end;
		$passtok = md5('$passwtok');
		$domtok = md5('$domaintok');
		$query = "INSERT INTO customers VALUES ";
		$query .= '(NULL,"' . $domain . '","' . $user . '","' . $passtok . '",NULL,"' . $domtok . '","' . $email . '","' . $first . '","' . $last . '","' . $middle . '","' . $areacode . '","' . $phone . '","' . $zip . '");';

//		$query .= '(NULL,"' . $domain . '","' . $user . '","' . md5('$begin$pass$end') . '",NULL,"' . md5('$begin$domain$end') . '","' . $email . '","' . $first . '","' . $last . '","' . $middle . '","' . $areacode . '","' . $phone . '","' . $zip . '");';
		$result = $conn->query($query);
		if (!$result) echo "INSERT failed: $query<br>" .
			$conn->error . "<br/><br/>";
		reset($_POST);		
	}

	$query = 'SELECT * FROM customers;';
	$resultb = $conn->query($query);
	if (!$resultb) die("Database access failed: $conn->error");

	$rows = $resultb->num_rows;
	echo $rows . ' Customers<br/><br/>';
	for ($j = 0; $j < $rows; ++$j) {
		$resultb->data_seek($j);
		$row = $resultb->fetch_array(MYSQLI_NUM);

	echo	'<br>Domain:' . $row[1];
	echo	'<br>User:' . $row[2];
	echo	'<br>Password:********';
	echo	'<br>Sign up:' . $row[4];
	echo	'<br>Token:' . $row[5];
	echo	'<br>Email:' . $row[6];
	echo	'<br><form action="newcust.php" method="GET">';
	echo	'<input type="hidden" value="' . $row[0] . '" name="indx"/>';
	echo	'<input type="hidden" value="yes" name="delete"/>';
	echo	'<button type="submit">DELETE</button></form>';
	}
	$conn->close();
?>