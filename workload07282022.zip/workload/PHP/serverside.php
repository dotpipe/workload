<?php
	// Populate by JSON API
	// Login with User/Token
	// Get JSON by Running
	// User->fget_contents()
	// with base URL of client
	// --------------
	// fget_contents thru Dated
	// Date->fget_contents()
	// goes to Date->loadfromJSON()
	// --------------
	// Use variables of Dated to
	// Add/Remove/List Scheduling
	// Done.

	$conn = new mysqli('db5009558953.hosting-data.io:3306','dbu322303','RTYfGhVbN!3$','dbs8105296');
	$results = array();
	function throwError($err) { echo 'Error Logged: ' . $err . '<br/>', $conn; }

	class Note {
		public $date;
		public $desc;
		public $to;
		public $from;
		public $read;
		public $utoken;
	}

	class Logger {
		public $user;	
		public $results;
		public $attr;
		public $date;
		public $utoken;
		public $group;

		static function logAll($data, $conn) { 
			$data->base_url = $_SERVER['REMOTE_HOST'];
			$dbquery = 'INSERT INTO logdb VALUES (NULL,"' . $data->result . '","' . $data->attr . '",';
			$dbquery .= 'NULL,"' . $logins->group . '","' . $data->base_url . '","' . $data->utoken . '","';
			$dbquery .= $data->user . '");';
			$results = $conn->query($dbquery);
			if (!$results) { 
				echo "Log failure: " .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_POST);
		}
	}

	class Login {
		public $indx;
		public $uname;
		public $password;
		public $group;
		public $utoken;
		public $base_url;
		public $flag;
		public $users;
	}

	class UserData {
		public $indx;
		public $uname;
		public $password;
		public $usrlvl;
		public $usrgrp;
		public $utoken;
		public $adm;
		public $flag;
		public $base_url;
		public $email;
	}

	class Dated {
		//DBQuery
		public $dbquery;
		public $result;
		// String
		public $dtls;
		// Calendar Function, $conning
		public $yr;
		public $mo;
		// Real
		public $day;
		public $month;
		public $year;
		public $length;
		// On, Off
		public $singular;
		public $vacation;
		// Time (24 hr)
		public $start;
		public $end;
		//User Info
		public $indx;
		public $user_sched;
		public $utoken;
		//JSON Array
		public $jsonarr;
		public $json_enc;

		public function loadfromJSON($json, $conn) {
			$object = json_decode($json);
			foreach($object AS $name => $val) {
				$this->{$name} = $val;
			}
		}

//
		public function addDate($data, $conn) {
			if ($data->flag == 0) {
				throwError("Logged Out");
				return;
			}
			$try = new Logger();
			// * made for smart phones, watches, future stuff
			// $length is a length of days, not a date
			// use $day,$month,$year w/ or w/o $length
			// based on $multi boolean. Cross ref $vacation.
			// $start,$end are times to begin and end event.
			// $name is event. $dtls is details. $uname is for users
			// there may be > 1 events per day. Inc. vacations.

			// query to add multi day event (not a leave)
			// use $day,$month,$year,$name,$dtls for 1st date
			// use $length for last date.
			// $users->uname for multi-user experience:
			// admin gets full list of events
			$dbquery = 'INSERT INTO schedule ';
			$dbquery .= 'VALUES (NULL,"' . $data->utoken . '","' . $this->timea . '","' . $this->timez . '","' . $this->singular;
			$dbquery .= '","' . $this->date . '","' . $this->dtls . '","' . $data->uname . '","' . $data->usrlvl . '","' . $this->length . '","1","' . $data->whom . '");';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Entry Error &lt;Schedule&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_POST);
			if ($results) {
				$try->result = "Success";
				$try->attr = "Add Date"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else { 
				throwError("Add Date Denied"); $try->result = "Fail";
				$try->attr = "Add Date"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			Logger::logAll($try, $conn);
			
		}

		public function deactivateDate($data, $conn) {
			$try = new Logger();
			$dbquery = 'UPDATE schedule SET ACTIVE = "0", ACTION = "' . $data->uname . '" WHERE ID = "' . $data->indx;
			if ($data->adm == "on" && ! isset($data->whom))
				$dbquery .= '" AND GROUP_NO == "' . $data->usrgrp . '";';
			else 
				$dbquery .= '" AND USER = "' . $data->whom . '";';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Remove Error &lt;Schedule&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_POST);
			if ($results) {
				$try->result = "Success";
				$try->attr = "Deactivate Date"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else { 
				throwError("Denied Removal"); $try->result = "Fail";
				$try->attr = "Deactivate Date"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
		}

		public function activateDate($data, $conn) {
			$try = new Logger();
			$dbquery = 'UPDATE schedule SET ACTIVE = "1", ACTION = "' . $data->uname . '" WHERE ID = "' . $data->indx;
			if ($data->adm == "on" && ! isset($data->whom))
				$dbquery .= '" AND GROUP_NO = "' . $data->usrlvl . '";';
			else 
				$dbquery .= '" AND USER = "' . $data->uname . '";';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Remove Error &lt;Schedule&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_POST);
			if ($results) {
				$try->result = "Success";
				$try->attr = "Deactivate Date"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else { 
				throwError("Denied Removal"); $try->result = "Fail";
				$try->attr = "Deactivate Date"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
		}

//
		public function removeDate($data, $conn) {
			if (! isset($data->flag) || $data->flag != "1") {
				throwError("Logged Out");
				return;
			}
			$try = new Logger();
			// Use $this to delete
			// from calendar db rows
			// delete hash file w/ dtls
			$dbquery = 'DELETE FROM schedule ';
			$dbquery .= 'WHERE ID = "' . $data->indx . '" AND (USER = "' . $data->uname . '"';
			if ($data->adm == "on")
				$dbquery .= ' OR GROUP_NO = ' . $data-usrlvl;
			$dbquery .= ');';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Remove Error &lt;Schedule&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_POST);
			if ($results) {
				$try->result = "Success";
				$try->attr = "Remove Date"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else { 
				throwError("Denied Removal"); $try->result = "Fail";
				$try->attr = "Remove Date"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			Logger::logAll($try, $conn);
		}
//
		public function listMySchedule($data, $conn) {

			$try = new Logger();
			if (! isset($data->flag) || $data->flag != "1") {
				throwError("Logged Out");
				return;
			}
			// Get list of events
			// from date queried
			// list in table in day.php
			// radio inputs beside events
			// must be named for index
			$dbquery = 'SELECT DATE, START, END, LEN, DETAILS, ID FROM schedule ';
			$dbquery .= 'WHERE USER = "' . $data->uname . '" OR GROUP_NO = ' . $data->usrgrp . ';';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Listing Error &lt;Schedule&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_POST);
			$rows = $results->num_rows;
			$temp = '<table style="width:200;border:1px black solid;font-size:12px;">';
			$y = 5;
			if ($rows > 5) $y= 5;
			else $y = $rows;
			for ($x = 0; $x < $rows; $x++) {
				$results->data_seek($x);
				$row = $results->fetch_array(MYSQLI_NUM);
				$temp .= '<tr><td>' . $row[0] . '</td></tr><tr>';
				for ($j = 1; $j < 3; $j++) {
					$temp .= '<td>' . $row[$j];
					$temp .= '</td>';
				}
				$temp .= '</tr>';
				$temp .= '<tr><td colspan=3>' . $row[3];
				$temp .= '</td></tr>';
				$temp .= '<tr><td colspan=3>' . $row[4];
				$temp .= '</td><td style="text-align:right" colspan=3>';
				$temp .= '<span onclick=' . 'removeDate(' . $row[5] . ')>';
				$temp .= 'Remove Date</span></td></tr>';
			}
			$temp .= '</table>';

			$x = 0;
			foreach ($results AS $pez) {
				$this->jsonarr[] = $pez;
			}

			$this->json_enc = json_encode($this->jsonarr);

			if ($results) { $try->result = "Success";
				$try->attr = "List Schedule";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else {
				throwError("List Schedule Denied"); $try->result = "Fail";
				$try->attr = "List Schedule";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			Logger::logAll($try, $conn);
			return $this->json_enc;
		}

// 
		public function listSchedule($data, $conn) {
			$try = new Logger();
			if (! isset($data->flag) || $data->flag != "1") {
				throwError("Logged Out");
				return;
			}
			$conn = new mysqli('db5009558953.hosting-data.io:3306','dbu322303','!3$!3$','dbs8105296');
			$sched = $_POST['user_sched'];
			// Get list of events
			// from date queried
			// list in table in day.php
			// radio inputs beside events
			// must be named for index
			$dbquery = 'SELECT * FROM schedule ';
			$dbquery .= 'WHERE (LEN >= "' . date("Y-m-j") . '" OR ACTIVE = "1")';
			$dbquery .= ' AND GROUP_NO = "' . $data->usrlvl . '";';
			// My Schedule = 0 // User Schedule = 1 // Group Sched = 2
			if ($_POST['who_lookup'] == 0)
				$dbquery .= ' USER = "' . $data->uname . '"';
			else if ($_POST['who_lookup'] == 1)
				$dbquery .= ' USER = "' . $data->whom . '"';
			else if ($_POST['who_lookup'] == 2 && $_POST['group'] = $data->usrgrp)
				$dbquery .= ' GROUP_NO = "' . $data->usrgrp . '"';
			$dbquery .= ' AND TOKEN = "' . $data->utoken . '";';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Listing Error &lt;Schedule&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_POST);
			$rows = $results->num_rows;
			$temp = '<table style="border:1px black solid;font-size:12px;">';

			for ($x = 0; $x < $rows; $x++) {
				$results->data_seek($x);
				$row = $results->fetch_array(MYSQLI_NUM);
				$temp .= '<tr>';
				$temp .= '<table><tr>';
				for ($j = 3; $j < 5; $j++) {
					$temp .= '<td>&nbsp;';
					$temp .= $row[$j];
					$temp .= '</td>';
				}
				$temp .= '</tr>';
				$temp .= '<tr><td>' . $row[4];
				$temp .= '</td></tr><tr><td colspan=2 style="font-size:12px">' . $row[6];
				$temp .= '</tr><tr><td>' . $row[10] . '</td><td>' . $row[9] . '</td></tr>';
				if (row[10] == "1") {
					$temp .= '<tr><td style="color:red" onclick=' . 'deactiveDate(' . $row[0] .')';
					$temp .= 'colspan=2>Deactivate</td></tr>';
				}
				else {
					$temp .= '<tr><td style="color:red" onclick=' . 'activeDate(' . $row[0] .')';
					$temp .= 'colspan=2>Activate</td></tr>';
				}
				if ($x%5 == 0 || $x + 1 == $rows)
					$temp .= '</tr>';
			}
			$temp .= '</table>';
			echo $temp;

			if ($results) {
				$try->result = "Success";
				$try->attr = "List Schedule";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else { 
				throwError("Schedule Denied"); $try->result = "Fail";
				$try->attr = "List Schedule";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			Logger::logAll($try, $conn);
		}
	}

	class User {
		//Admin Responsibilities
		public $newpassw;
		public $newuser;
		public $repassw;
		//DBQuery
		public $dbquery;
		public $result;
		//Internals
		public $usrgrp;
		public $usrlvl;
		public $moduser;
		public $modgrp;
		public $password;
		public $uname;
		public $base_url;
		public $email;
		public $indx;
		public $adm;
		public $setadm;
		public $flag;
		public $utoken;
		public $whom;
		//JSON Array
		public $jsonarr;

		public function deactivateUser($data, $conn) {
			if ($data->adm != "on") { 
				throwError("Deactivate Denied"); $try->result = "Fail";
				$try->attr = "Deactivate User"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			$dbquery = 'UPDATE user SET ACTIVE = "0", ACTION = "' . $data->uname . '" WHERE ID = "' . $data->indx;
			if ($data->adm == "on")
				$dbquery .= '" AND GROUP_NO = "' . $data->usrlvl . '";';
			else 
				$dbquery .= '" AND USER = "' . $data->moduser . '";';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Remove Error &lt;Schedule&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_POST);
			if ($results) {
				$try->result = "Success";
				$try->attr = "Deactivate User"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else { 
				throwError("Deactivate Denied"); $try->result = "Fail";
				$try->attr = "Deactivate User"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
		}

		public function activateUser($data, $conn) {
			if ($data->adm != "on") { 
				throwError("Deactivate Denied"); $try->result = "Fail";
				$try->attr = "Deactivate User"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			$dbquery = 'UPDATE user SET ACTIVE = "1", ACTION = "' . $data->uname . '" WHERE ID = "' . $data->indx;
			if ($data->adm == "on")
				$dbquery .= '" AND GROUP_NO = "' . $data->usrlvl . '";';
			else 
				$dbquery .= '" AND USER = "' . $data->moduser . '";';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Remove Error &lt;Schedule&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_POST);
			if ($results) {
				$try->result = "Success";
				$try->attr = "Deactivate User"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else { 
				throwError("Deactivate Denied"); $try->result = "Fail";
				$try->attr = "Deactivate User"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
		}
//
		public function modifyUsr($data, $conn) {
			$try = new Logger();
			if (! isset($data->flag) || $data->flag != "1") {
				throwError("Logged Out");
				return;
			}

			if ($data->adm != "on") {
				throwError("You do not have adequate permissions"); $try->result = "Fail";
				$try->attr = "Modify User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
				Logger::logAll($try, $conn);
				return;
			}

			$dbquery = 'SELECT USER, ID, GROUP_NO FROM user WHERE USER = "' . $data->moduser . '"';
			$dbquery .= ' AND TOKEN = "' . $data->utoken . '";';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Modify Error &lt;User&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_POST);
			$rows = $results->num_rows;
			$results->data_seek(0);
			$row = $results->fetch_array(MYSQLI_NUM);
			if ($row[0] != $data->moduser) {
				throwError("User Does Not Exist");
				$try->result = "Fail";
				$try->attr = "Modify User"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
				Logger::logAll($try, $conn);
				return;
			}
			else {
				$reset($dbquery1);
				if ($row[2] <= $data->usrgrp && $data->modgrp <= $data->usrgrp) {
					if (isset($data->modgrp)) {
						$dbquery1 .= ' GROUP_NO = ' . $data->modgrp;
					}
					if (isset($data->email)) {
						if (isset($dbquery1))
							$dbquery1 .= ',';
						$dbquery1 .= ' EMAIL = "' . $data->email;
					}
					if (isset($data->newpassw)) {
						if (isset($dbquery1))
							$dbquery1 .= ',';
						$dbquery1 .= ' PASSWORD = ' . $data->newpassw;
					}
					if (isset($data->is_admin)) {
						if (isset($dbquery1))
							$dbquery1 .= ',';
						$dbquery1 .= ' ADMIN = ' . $data->is_admin;
					}
					$dbquery .= ' WHERE USER = ' . $data->moduser;
					$results = $conn->query($dbquery);
					if (!$results) echo "Modify User Error: " .
						$conn->error . "<br/><br/>";
					else reset($_POST);
				}
				else { throwError("You do not have adequate permissions"); $results = ""; }

				if ($results) {
					$try->result = "Success";
					$try->attr = "Modify User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
					$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
				}
				else { 
					throwError("You do not have adequate permissions"); $try->result = "Fail";
					$try->attr = "Modify User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
					$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
				}
				Logger::logAll($try, $conn);
			}
		}

//
		public function switchUser($data, $lvl, $conn) {
			if (! isset($data->flag) || $data->flag != "1") {
				throwError("Logged Out");
				return;
			}

			if ($data->adm != "on") {
				throwError("You do not have adequate permissions"); $try->result = "Fail";
				$try->attr = "Switch User Level";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
				Logger::logAll($try, $conn);
				return;
			}
			$try = new Logger();

			if ($data->usrgrp >= $lvl)
				$data->usrlvl = $lvl;
			else { throwError("User Level Too High"); }
			
			if ($data->usrlvl == $lvl) {
				$try->result = "Success";
				$try->attr = "SU Level";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else { 
				throwError("You do not have adequate permissions"); $try->result = "Fail";
				$try->attr = "SU Level";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			Logger::logAll($try, $conn);
		}

//
		public function loadfromJSON($json, $conn) {
			$object = json_decode($json);
			foreach($object AS $name => $val) {
				$this->{$name} = $val;
			}
		}

//
		public function get_client_id($data, $conn) {
			$try = new Logger();

			// Get $results (USER) query from db
			// get index from db
			$dbquery = 'SELECT USER, TOKEN, GROUP_NO, ADMIN FROM user ';
			$dbquery .= 'WHERE USER = "' . $data->uname . '" AND TOKEN = "' . $data->utoken . '";';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Login Error &lt;Step 2&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_POST);
			$results->data_seek(0);
			$row = $results->fetch_array(MYSQLI_NUM);
			if ($data->uname == $row[0]) {
				$data->uname = $row[0];
				$data->group = $row[2];
				if ($row[3])
					$data->adm = "on";
				else $data->adm = 0;
				$data->flag = 1;
				if ($data->utoken == $row[1])
					$data->flag = 2;
			}
			else { $data->flag = 0; }

			if ($data->flag == 1) {
				$try->result = "Success";
				$try->attr = "Getting Attributes";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else if ($data->flag == 2) {
				throwError("Invalid Login"); $try->result = "Fail";
				$try->attr = "Granting Token Access";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else {
				throwError("Invalid Login"); $try->result = "Fail";
				$try->attr = "Getting Attributes";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			Logger::logAll($try, $conn);
		}

		function listUsers($conn) {
			if (! isset($this->flag) || $this->flag != "1") {
				throwError("Logged Out");
				return;
			}

			$dbquery = 'SELECT ID, USER, GROUP_NO, EMAIL, LAST, ADMIN FROM user WHERE TOKEN = "' . $this->utoken . '";';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Listing Error &lt;Users&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_POST);
			$temp = $results->num_rows . ' Users Returned';
			$temp = '<table style="cursor:default;border:1px black solid;font-size:12px;">';
			$temp .= '<tr><td>USER</td><td>GROUP_NO</td><td>EMAIL</td><td>LAST</td><td>ADMIN</td></tr>';
			$rows = $results->num_rows;
			for ($x = 0; $x < $rows; $x++) {
				$results->data_seek($x);
				$row = $results->fetch_array(MYSQLI_NUM);
				$temp .= '<tr>';
				$temp .= '<form method="POST">';
				$temp .= '<input type="hidden" name="idx" value="' . $row[0] . '"/>';
				for ($j = 1; $j < 4; $j++) {
					$temp .= '<td style="text-align:left">';
					$temp .= $row[$j];
					$temp .= '</td>';
				}
				$temp .= '<td style="border-bottom:1px black dashed;color:red;text-align:right">';
				$temp .= '<button ';
				if ($row[2] >= $this->usrlvl && $this->adm != "on")
					$temp .= 'disabled ';
				$temp .= 'style="border:0px;" type="submit" onclick=' . 'removeUser(' . $row[0] . ')>';
				$temp .= 'Remove User</button></form></td></tr>';
				$temp .= '<td style="border-bottom:1px black dashed;color:red;text-align:right">';
				if ($row[2] <= $this->usrgrp && $this->adm == "on") {
					if ($row[9] == 1) {
						$temp .= '<form method="POST"><button style="border:0px;" type="submit" onclick=' . 'deactiveUser(' . $row[0] . ')>';
						$temp .= 'Deactivate User</button></form></td></tr>';
					}
					else {
						$temp .= '<form method="POST"><button style="border:0px;" type="submit" onclick=' . 'activeUser(' . $row[0] . ')>';
						$temp .= 'Activate User</button></form></td></tr>';
					}
				}

			}
			$temp .= '</table>';
			echo $temp;
		}
	}

	global $dates;
	global $logins;
	global $users;
	global $notes;

	$dates = new Dated();
	$logins = new Login();
	$users = new User();
	$notes = new Note();
		if(isset($_POST['usr'])) { $users->uname = $_POST['usr']; } //
		if(isset($_POST['pw'])) { $users->password = $_POST['pw']; } //
		if(isset($_POST['newuser'])) { $users->newuser = $_POST['newuser']; } //
		if(isset($_POST['newpw'])) { $users->newpassw = $_POST['newpw']; } //
		if(isset($_POST['repw'])) { $users->repassw = $_POST['repw']; } //
		if(isset($_POST['moduser'])) { $users->moduser = $_POST['moduser']; } //
		if(isset($_POST['modgrp'])) { $users->modgrp = $_POST['modgrp']; } //
		if(isset($_POST['grp'])) { $users->usrlvl = $users->usrgrp = $_POST['grp']; } //
		if(isset($_POST['email'])) { $users->email = $_POST['email']; } //
		if(isset($_POST['singular'])) { $dates->singular = $_POST['singular']; } //
		if(isset($_POST['y'])) { $dates->year = $_POST['y']; } //
		if(isset($_POST['m'])) { $dates->month = $_POST['m']; } //
		if(isset($_POST['d'])) { $dates->day = $_POST['d']; } //
		if(isset($_POST['dy'])) { $dates->year = $_POST['dy']; } //
		if(isset($_POST['dm'])) { $dates->month = $_POST['dm']; } //
		if(isset($_POST['vacation'])) { $dates->vacation = $_POST['vacation']; } //
		if(isset($_POST['perm'])) { $dates->perm = $_POST['perm']; } //
		if(isset($_POST['length'])) { $dates->length = $_POST['length']; } //
		if(isset($_POST['dtls'])) { $dates->dtls = $_POST['dtls']; } //
		if(isset($_POST['all'])) { $dates->all = $_POST['all']; } //
		if(isset($_POST['password'])) { $logins->password = $_POST['password']; } //
		if(isset($_POST['inusr'])) { $logins->uname = $_POST['inusr']; } //
		if(isset($_POST['idx'])) { $users->indx = $_POST['idx']; } //
		if(isset($_POST['is_admin'])) { $users->adm = $_POST['is_admin']; } //
		if(isset($_POST['set_admin'])) { $users->setadm = $_POST['set_admin']; } //
		if(isset($_POST['recp'])) { $notes->to = $_POST['recp']; } //
		if(isset($_POST['dtls'])) { $users->desc = $_POST['dtls']; } //
		if(isset($_POST['begin'])) { $dates->begin = $_POST['begin']; } //
		if(isset($_POST['sched_whom'])) { $users->whom = $_POST['sched_whom']; } //
		if(isset($_SERVER['HTTP_ORIGIN'])) {
			$begin = 'BId74i'; $end = 'sDI0j';
			$domaintok = md5($begin . $_SERVER['HTTP_ORIGIN'] . $end);
			$users->utoken = $domaintok;
		} //

	function logout($conn) {
		$logins->flag = 0;
	}

//
	function loginChallenge($data, $conn) {
		// The base_url (remote host)
		// is needed to protect users
		// Only 3 different remote hosts allowed
		// v--Not sure how to wrap JS and PHP
		$try = new Logger();
		$data->base_url = $_SERVER['HTTP_ORIGIN']; //check incoming IP
		
		$dbquery = 'SELECT USER, PASSWORD, TOKEN ';
		$dbquery .= 'FROM customers WHERE USER = "' . $data->uname . '" AND TOKEN = "' . $data->utoken . '";';
		//$dbquery .= ' AND ACTIVE = 1;';
		$results = $conn->query($dbquery);
		if (!$results) {
			echo "Login Error &lt;Step 1&gt;: " .
			$conn->error . "<br/><br/>";
			return;
		}
		else reset($_POST);
		if ($results) {
			$try->result = "Success";
			$try->attr = "Login";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $logins->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		
			$begin = 'BId74i'; $end = 'sDI0j';
			$pastok = md5($begin . $logins->password . $end);
			$rows = $results->num_rows;
			var_dump($logins);
			for ($j = 0; $j < $rows;$j++) {
				$results->data_seek($j);
				$row = $results->fetch_array(MYSQLI_NUM);
				if ($pastok == $row[1] &&
					$logins->uname == $row[0]){// &&
					// $users->utoken == $row[2]) {
					get_client_id($data);
					$try->result = "Success";
					$try->attr = "Login";
					$try->base_url = $_SERVER['REMOTE_ADDR']; $try->user = $data->uname;
					$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
					break;
				}
				else if ($data->inusr != $row[0])
				{
					throwError("Invalid Login");
					$try->result = "Fail";
					$try->attr = "Login (Username)";  $try->base_url = $_SERVER['REMOTE_ADDR'];
					$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
				}
				else if ($pastok != $row[1])
				{
					throwError("Invalid Login");
					$try->result = "Fail";
					$try->attr = "Login (Password)";  $try->base_url = $_SERVER['REMOTE_ADDR'];
					$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
					
				}
				else { $logins->flag = 0; }
			}
		}
		else {
			throwError("Invalid Login");
			$try->result = "Fail";
			$try->attr = "Login";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		if ($logins->flag == 1)
			fget_contents($logins->base_url);
		else {
			throwError("Invalid Login");
			$try->result = "Fail";
			$try->attr = "Login";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		Logger::logAll($try, $conn);
	}

//
	function commitChanges($data, $conn) {
		$try = new Logger();
		if (! isset($data->flag) || $data->flag != "on") {
			throwError("Logged Out");
			return;
		}
		if ($data->adm != "on") {
			throwError("You do not have adequate permissions"); $try->result = "Fail";
			$try->attr = "Commit Changes";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			Logger::logAll($try, $conn);
			return;
		}
		$dbquery = 'COMMIT;';
		$results = $conn->query($dbquery);
			if (!$results) {
				echo "SQL Error &lt;Commit&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
		else reset($_POST);
		if ($results) {
			$try->attr = "Commit";
			$try->result = "Success";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		else { $try->attr = "Commit"; $try->result = "Fail";
			 $try->base_url = $_SERVER['REMOTE_ADDR']; $try->user = $data->uname;
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		Logger::logAll($try, $conn);
	}

	function fget_contents($url, $conn) {
		$json = file_get_contents($url);
		$this->loadfromJSON($json);
	}
//
	function rollbackChanges($data, $conn) {
		$try = new Logger();
		if (! isset($data->flag) || $data->flag != "1") {
			throwError("Logged Out");
			return;
		}
		if ($data->adm != "on") {
			throwError("You do not have adequate permissions"); $try->result = "Fail";
			$try->attr = "Rollback Changes";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			Logger::logAll($try, $conn);
			return;
		}
		$dbquery = 'ROLLBACK;';
		$results = $conn->query($dbquery);
		if (!$results) {
			echo "SQL Error &lt;Rollback&gt;:" .
			$conn->error . "<br/><br/>";
			return;
		}
		else reset($_POST);
		if ($results) {
			$try->attr = "Rollback";
			$try->result = "Success";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		else { $try->attr = "Rollback"; $try->result = "Fail";
			 $try->base_url = $_SERVER['REMOTE_ADDR']; $try->user = $data->uname;
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		Logger::logAll($try, $conn);
	}
//
	function changePassword($data, $conn) {
		if ($_POST['old_passw'] == $data->password) {
			$begin = 'BId74i'; $end = 'sDI0j';
			$pastok = md5("$begin" . $data->newpassw . "$end");
			if ($_POST['new_passw'] == $_POST['new_passw_rpt'])
				$dbquery = 'UPDATE user SET PASSWORD = "' . $hasher . '", ACTION = "' . $data->uname . '" WHERE USER = "' . $data->uname . '";';
			$results = ($dbquery);
			if (!$results) {
				echo "Modify Error &lt;Password&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_POST);
		}
		if ($results) {
			$try->attr = "Change Password";
			$try->result = "Success";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		else { $try->attr = "Change Password"; $try->result = "Fail";
			 $try->base_url = $_SERVER['REMOTE_ADDR']; $try->user = $data->uname;
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
	}

	function refreshering($conn) {
		require("/PHP/workload.php");
	}

	function addUser($data, $conn) {
		$try = new Logger();
		if (! isset($data->flag) || $data->flag != "1") {
			throwError("Logged Out");
			return;
		}
		if ($data->adm != "on") {
			throwError("You do not have adequate permissions"); $try->result = "Fail";
			$try->attr = "Add User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			Logger::logAll($try, $conn);
			return;
		}
		$begin = 'BId74i'; $end = 'sDI0j';
		$pastok = md5("$begin" . $data->newpassw . "$end");
		$domaintok = md5("$begin" . $_SERVER['HTTP_ORIGIN'] . "end");
		$dbquery = 'SELECT USER FROM user WHERE USER = ' . $data->newuser . ' AND TOKEN = ' . $data->utoken . ';';
		$results = $conn->query($dbquery);
		if (!$results) {
			echo "Entry Error &lt;User (1)&gt;: " .
			$conn->error . "<br/><br/>";
			return;
		}
		if ($results->num_rows != 0) {
			echo "User Exists";
			return;
		}
		$dbquery = "INSERT INTO user VALUES";
		$dbquery .= '(NULL,"' . $domaintok . '","' . $data->newuser . '","' . $passtok . '","' . $data->setadm . '",NULL,"' . $data->email . '","' . $data->group . '",NULL)';

		$results = $conn->query($dbquery);
			if (!$results) {
				echo "Entry Error &lt;User (2)&gt;: " .
				$conn->error . "<br/><br/>";
				return;
			}
		else reset($_POST);
		if ($results) {
			$try->result = "Success";
			$try->attr = "Add User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		else { 
			throwError("Add User Denied"); $try->result = "Fail";
			$try->attr = "Add User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		Logger::logAll($try, $conn);
	}

	function addNote($data, $conn) {
		$try = new Logger();
		if (! isset($data->flag) || $data->flag != "1") {
			throwError("Logged Out");
			return;
		}
		$begin = 'BId74i'; $end = 'sDI0j';
		$pastok = md5("$begin" . $data->password . "$end");
		$domaintok = md5("DfOdd@f" . $_SERVER['HTTP_ORIGIN'] . "sD1o0J");
		$data->date = date("Y") . '-' . date("m") . '-' . $date("j");
		$data->read = 0;
		$dbquery = 'INSERT INTO notes';
		$dbquery .= ' VALUES (NULL,"' . $data->date . '","' . $data->to . '","' . $data->from . '","' . $data->dtls . '","' . $domaintok . '","' . $data->read . '","' . $data->admins_only . '"';
		if ($data->adm == "on")
			$dbquery .= '","1",';
		else $dbquery .= '","0",';
		$dbquery .= '"' . $data->usrgrp . '");';
		$results = $conn->query($dbquery);
			if (!$results) {
				echo "Entry Error &lt;Notes&gt;: " .
				$conn->error . "<br/><br/>";
				return;
			}
		else reset($_POST);
		if ($results) {
			$try->result = "Success";
			$try->attr = "Add Note";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->from; $try->group = $users->grplvl;
		}
		else { 
			throwError("Add Note Denied"); $try->result = "Fail";
			$try->attr = "Add Note";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->from; $try->group = $users->grplvl;
		}
		Logger::logAll($try, $conn);
	}

	function remuser($data, $conn) {
		$try = new Logger();
		if (! isset($data->flag) || $data->flag != "1") {
			throwError("Logged Out");
			return;
		}
		if ($data->adm != "on") {
			throwError("You do not have adequate permissions"); $try->result = "Fail";
			$try->attr = "Remove User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			Logger::logAll($try, $conn);
			return;
		}
		// Use $this to delete
		// from calendar db rows
		// delete hash file w/ dtls
		$dbquery = 'DELETE FROM user ';
		$dbquery .= 'WHERE ID = "' . $data->indx . '" AND GROUP_NO < "' . $data->usrlvl . '"';
		$dbquery .= ' AND TOKEN = "' . $data->utoken . '"';
		$results = $conn->query($dbquery);
			if (!$results) {
				echo "Remove Error &lt;User&gt;: " .
				$conn->error . "<br/><br/>";
				return;
			}
		else reset($_POST);
		if ($results) {
			$try->result = "Success";
			$try->attr = "Remove User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		else { 
			throwError("Denied User Removal"); $try->result = "Fail";
			$try->attr = "Remove User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		Logger::logAll($try, $conn);
	}

	function listSideNotes($data, $conn) {
		$results = array();

		$conn = new mysqli('db5009558953.hosting-data.io:3306','dbu322303','!3$!3$','dbs8105296');
		$dbquery = 'SELECT * FROM notes WHERE (RCPT = ';
		$dbquery .= '"' . $data->uname . '" AND TOKEN = "' . $data->utoken . '")';
		if ($data->adm == "on")
			$dbquery .= ' AND ADMINS_EYES = "1" OR GROUP_NO < "' . $data->usrgrp . '"';
		else $dbquery .= ' AND ADMINS_EYES = "0"';
		$dbquery .= ' AND SEEN = "0";';
		$results = $conn->query($dbquery);
		if (!$results) {
			echo "Listing Error &lt;Notes&gt;: " .
			$conn->error . "<br/><br/>";
			return;
		}
		else reset($_POST);
		$temp = '<table style="cursor:default;border:1px black solid;font-size:12px;">';

		$rows = $results->num_rows;
		if ($rows > 5)
			$y = 5;
		else $y = $rows;
		for ($x = 0; $x < $y; $x++) {
			$results->data_seek($x);
			$row = $results->fetch_array(MYSQLI_NUM);
			if ($row[9] > $data->usrgrp || ($row[7] == 1 && $data->adm != "on")) {
				$y++;
				continue;
			}
			$temp .= '<tr>';
			$temp .= '<td>' . $row[1] . '</td>';

			$temp .= '<td>';
			$temp .= $row[3];
			$temp .= '</td>';
			$temp .= '</tr>';

			$temp .= '<tr><td colspan=2>' . $row[4];
			$temp .= '</td></tr>';
			if ($row[7] == 1 && $data->adm == "on") {
				$temp .= '<tr><td colspan=2 style="color:red">Admins Only</td></tr>';
			}
			$temp .= '<tr><td colspan=2 style="border-bottom:1px black dashed;color:red;text-align:right">';
			if ($row[2] == $data->uname ||
				$row[9] < $data->usrgrp ||
				$row[3] == $data->uname) {
				$temp .= '<span onclick=' . 'readNote(' . $row[0] . ')>';
				$temp .= 'Mark Read</span></td></tr>';
			}
		}
		$temp .= '</table>';
		echo $temp;
	}

	function listNotes($data, $conn) {
		if (! isset($data->flag) || $data->flag != "1") {
			throwError("Logged Out");
		//	return;
		}
		$dbquery = 'SELECT * FROM notes WHERE RCPT = ';
		$dbquery .= '"' . $data->uname . '" AND TOKEN = "' . $data->utoken . '"';
		if ($data->adm == "on")
			$dbquery .= ' AND ADMINS_EYES = "1"';
		else $dbquery .= ' AND ADMINS_EYES = "0"';
		$dbquery .= ' AND SEEN = "0";';
		$results = $conn->query($dbquery);
			if (!$results) {
				echo "Listing Error &lt;Notes&gt;: " .
				$conn->error . "<br/><br/>";
				return;
			}
		else reset($_POST);
		$temp = '<table style="cursor:default;border:1px black solid;font-size:12px;">';

		$rows = $results->num_rows;
		for ($x = 0; $x < $rows; $x++) {
			$results->data_seek($x);
			$row = $results->fetch_array(MYSQLI_NUM);
			if ($row[9] > $data->usrgrp || ($row[7] == 1 && $data->adm != "on"))
				continue;
			$temp .= '<tr>';
			$temp .= '<td>' . $row[1] . '</td>';

			$temp .= '<td>';
			$temp .= $row[3];
			$temp .= '</td>';
			$temp .= '</tr>';

			$temp .= '<tr><td colspan=2>' . $row[4];
			$temp .= '</td></tr>';
			if ($row[7] == 1 && $data->adm == "on") {
				$temp .= '<tr><td colspan=2 style="color:red">Admins Only</td></tr>';
			}
			$temp .= '<tr><td colspan=2 style="border-bottom:1px black dashed;color:red;text-align:right">';
			if (($row[2] == $data->uname) ||
				($row[9] < $data->usrgrp && $data->adm == "on") ||
				$row[3] == $data->uname) {
				$temp .= '<span ';
				if ($row[8] == 1 && $data->adm != "on") {
					$temp .= 'style="color:blue">';
					$temp .= 'From Admin</span></td></tr>';
				}
				else {
					$temp .= 'onclick=' . 'readNote(' . $row[0] . ')>';
					$temp .= 'Mark Read</span></td></tr>';
				}
			}
		}
		$temp .= '</table>';
		echo $temp;
	}

	function markRead($data, $conn) {
		$dbquery = 'UPDATE notes SET SEEN = 1; WHERE ID = "' . $data->indx . '"';
		$dbquery .= ' AND TOKEN = "' . $data->utoken . '"';
		$results = $conn->query($dbquery);
		if (!$results) {
			echo "Read Error: " .
			$conn->error . "<br/><br/>";
			return;
		}
		else reset($_POST);
	}

	if (isset($_POST['login_change_password'])) {
		changePassword($users, $conn);
		reset($_POST);
	}

	if (isset($_POST['read_notes'])) {
		markRead($_POST['read_notes']);
		reset($_POST);
	}

	if (isset($_POST['listing_notes'])) {
		listNotes($users, $conn);
		reset($_POST);
	}

	if (isset($_POST['listing_side_notes'])) {
		listSideNotes($users, $conn);
		reset($_POST);
	}

	if (isset($_POST['login_credentials'])) {
		loginChallenge($users, $conn);
		reset($_POST);
	}

	if (isset($_POST['add_users_func']) && $users->adm == "on") {
		adduser($users, $conn);
		reset($_POST);
	}

	if (isset($_POST['list_users_func']) && $users->adm == "on") {
		$users->listUsers();
		reset($_POST);
	}

	if (isset($_POST['rem_users_func']) && $users->adm == "on") {
		remuser($users, $conn);
		reset($_POST);
	}

	if (isset($_POST['add_date_func'])) {
		$dates->addDate($users, $conn);
		reset($_POST);
	}

	if (isset($_POST['log_out_func'])) {
		$logout($users, $conn);
		reset($_POST);
	}

	if (isset($_POST['rem_date_func'])) {
		remdate($users, $conn);
		reset($_POST);
	}

	if (isset($_POST['commit_changes']) && $users->adm == "on") {
		commitChanges($users, $conn);
		reset($_POST);
	}

	if (isset($_POST['rollback_changes']) && $users->adm == "on") {
		rollbackChanges($users, $conn);
		reset($_POST);
	}

	if (isset($_POST['whois'])) {
		if (isset($_POST['user_sched']) && $_POST['user_sched'] != "") {
			$dates->user_sched = $_POST['user_sched'];
		}
		$dates->listSchedule($users, $conn);
		reset($_POST);
	}

	if (isset($_POST['whois_side'])) {
		$dates->listMySchedule($users, $conn);
		reset($_POST);
	}

	if (isset($_POST['list_my_notes'])) {
		listNotes($users, $conn);
		reset($_POST);
	}

	if (isset($_POST['add_note_func'])) {
		$notes->utoken = $users->utoken;
		$notes->from = $users->uname;
		addNote($notes);
		reset($_POST);
	}

	if (isset($_POST['start_login'])) {
		loginChallenge($logins, $conn);
	}

	if (isset($_POST['deactive_date'])) {
		$users->indx = $_POST['n'];
		deactivateDate();
		reset($_POST);
	}

	if (isset($_POST['active_date'])) {
		$users->indx = $_POST['n'];
		activateDate();
		reset($_POST);
	}

	if (isset($_POST['deactive_user'])) {
		$users->indx = $_POST['n'];
		deactivateUser($users, $conn);
		reset($_POST);
	}

	if (isset($_POST['active_user'])) {
		$users->indx = $_POST['n'];
		activateUser($users, $conn);
		reset($_POST);
	}

?>