<?php
require_once("serverside.php");
$d = date("j");
$m = $pm = $am = date("m");
$am++; $pm--;
$Y = $aY = $pY = date("Y");
if(isset($_GET['m'])) { $m = $_GET['m']; $am = $m + 1; $pm = $m - 1; }
if(isset($_GET['y'])) { $Y = $_GET['y']; }
if($am > 12) { $am = 1; $aY++; }
if($pm < 1) { $pm = 12; $pY--; }

	echo '<form method="POST">';
	echo '<table style="text-align:top" width="50%" cellpadding="3"><tr>';
	echo '<td style="cursor:default">Username</td>';
	echo '<td style="cursor:default">Password</td><td style="padding-left:14px"><input name="set_admin" type="checkbox"> Admin</input></td><td style="padding-left:14px"><input name="set_active" checked="checked" type="checkbox"> Active</input></td><td></td></tr>';
	echo '<tr><td style="text-align:center;border-top:1px black dotted;border-left:1px black dotted"><input type="textbox" width="5" name="newuser" required/></td>';
	echo '<td style="text-align:center;border-top:1px dotted black;"><input type="password" style="width:225" name="newpw" width="5" required/></td>';
	echo '<td style="text-align:left;border-top:1px dotted black;border-right:1px dashed black;border-bottom:1px dotted black;cursor:default"><input option type="radio" value="0" name="addmod"> Add User</option></td>';
	echo '<td style="text-align:left;border-top:1px black dotted;border-right:1px dotted black;text-align:center;cursor:default"><input option type="radio" name="addmod" value="1"/> Modify User</option></td>';
	echo '<td style="font-size:32px;padding:5px" rowspan="3"><button onclick=addUser() style="border:1px;color:green;background-color:white;">+</button></td>';
	echo '<td style="font-size:32px;padding:5px" rowspan="3"><span style="border:0px;color:black;background-color:white;cursor:pointer;" onclick=' . 'callPHPHead("month",' . $m . "," . $Y . "," . $d . ')>x</span></td></tr>';
	echo '<td style="border-left:1px black dotted;cursor:default">Group Level</td>';
	echo '<td style="cursor:default">Retype Password</td>';
	echo '<td style="border-right:1px black dotted;" colspan=2><span style="cursor:default;">Email Address</td>';
	echo '<tr><td style="text-align:center;border-left:1px black dotted;border-bottom:1px black dotted;border-right:0px black none;"><input type="number" name="grp" required/></td>';
	echo '<td style="text-align:center;border-bottom:1px black dotted;"><input style="width:225" type="password" name="repw" required/></td>';
	echo '<td style="text-align:center;border-bottom:1px black dotted;" colspan="2"><input style="width:225" type="textbox" name="email" required/></form></td>';
	echo '</tr></table><br/>';

	$users->listUsers();
?>