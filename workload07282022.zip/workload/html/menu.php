<?php

	$temp = '<table style="width:125;cursor:pointer;border:5px teal solid;font-size:20px;background-color:' . $profile->background . '">';
	$temp .= '<tr><td style="padding:10px;border:5px teal solid;"><span onclick=' . 'callPHPHead("newcust",' . $m . ',' . $Y . ',' . $d . ')>Sign Up</span><br/></td></tr>';
	$temp .= '<tr><td style="padding:10px;border:5px teal solid;"><span onclick=' . 'callPHPHead("month",' . $m . ',' . $Y . ',' . $d . ')>Calendar</span><br/></td></tr>';
	$temp .= '<tr><td style="padding:10px;border:5px teal solid;"><span onclick=' . 'callPHPHead("sched",' . $m . ',' . $Y . ',' . $d . ')>Schedule</span><br/></td></tr>';
	$temp .= '<tr><td style="padding:10px;border:5px teal solid;"><span onclick=' . 'callPHPHead("notes",' . $m . ',' . $Y . ',' . $d . ')>Notebox</span><br/></td></tr>';
	if ($users->flag == "1" && $users->admin == "1")
		$temp .= '<tr><td style="padding:10px;border:5px teal solid;"><span onclick=' . 'callPHPHead("user",' . $m . ',' . $Y . ',' . $d . ')>Admin</span><br/></td></tr>';

	$temp .= '<tr><td style="padding:10px;border:5px teal solid;"><span onclick=' . 'callPHPHead("login",' . $m . ',' . $Y . ',' . $d . ')>Login</span><br/></td></tr>';
	$temp .= '</table>';
	echo $temp;
?>