<?php session_start(); ?>
<html>
<title>WorkLoad - Collaborator</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>
<link rel="stylesheet" href="css/w3.css">
<script src="scripts.js"></script>

<?php
 require_once("PHP/serverside.php");
 require_once("PHP/startup.php");
$d = date("j");
$m = $pm = $am = date("m");
$am++; $pm--;
$Y = $aY = $pY = date("Y");
if(isset($_GET['m'])) { $m = $_GET['m']; $am = $m + 1; $pm = $m - 1; }
if(isset($_GET['y'])) { $Y = $_GET['y']; }
if($am > 12) { $am = 1; $aY++; }
if($pm < 1) { $pm = 12; $pY--; }

?>
</head>

<body style="margin-top:0;margin-bottom:0px;" onload="callIndex();flatCalendar();">

<div id="idAll">
<p id="showAll"></p>
</div>
</body>
</html>