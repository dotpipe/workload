<?php
require("../PHP/startup.php");
$URL = "showMo";

if(isset($_GET['u'])) { $URL = $_GET['u']; }


	$txt =  '<div class="w3-modal-content">';
	$txt .= '<header class="w3-container" style="background:' . $profile->background . '">';
	$txt .= '<h2><center>';
	$txt .= '<span style="cursor:default">';
	$txt .= 'Notebox';
	$txt .= '</span></center>';
	$txt .= '</h2></header>';
	echo $txt; $txt = '';
	$txt = '<div class="w3-container">';
	$txt .= '<p id="' . $URL . '"></p>';
	$txt .= '</div>';
	echo $txt; $txt = '';
	$txt .= '<footer class="w3-container" style="background:' . $profile->background . '">';
	$txt .= '<p>Copyright - ' . date("Y") . '</p>';
	$txt .= '</footer></div>';
	echo $txt;
?>