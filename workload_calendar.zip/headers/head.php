<?php
require_once("../PHP/startup.php");

$URL = "showMo";
$d = date("j");
$m = $pm = $am = date("m");
if(! isset($Y)) { $Y = date("Y"); }
if(isset($_GET['m'])) { $m = $_GET['m']; }
if(isset($_GET['y'])) { $Y = $_GET['y']; }
if(isset($_GET['u'])) { $URL = $_GET['u']; }
$am = $m + 1; $pm = $m - 1;

	$txt =  '<div class="w3-modal-content">';
	$txt .= '<header class="w3-container" style="background:' . $profile->background . '">';
	$txt .= '<h2><center><span ';
	$txt .= 'onclick=' . 'callPHPHead("month",'; 
	$pY = $Y;
	if ($m - 1 == 0) { $pm = 12; $pY = $Y - 1; }
	else { $pm = $m - 1; }
	$txt .= $pm . ',' . $pY;
	$txt .= ',1) style="cursor:pointer"> &#8647;</span>';
	$dto = date_create("1-$m-$Y");
	$ddate = date_format($dto, "M/Y");
	$txt .= '<span style="cursor:default"> Schedule for ' . $ddate;
	$txt .= '</span><td id="week"><span onclick=' . 'callPHPHead("month",';
	$aY = $Y;
	if ($m + 1 == 13) { $am = 1; $aY = $Y + 1; }
	else { $am = $m + 1; }
	$txt .= $am . ',' . $aY;
	$txt .= ',1) style="cursor:pointer"> &#8649;</span></center>';
	$txt .= '</h2></header>';
	echo $txt; $txt = '';
	$txt = '<div class="w3-container">';
	$txt .= '<p id="' . $URL . '"></p>';
	$txt .= '</div>';
	$txt .= '<footer class="w3-container" style="background:' . $profile->background . '">';
	$txt .= '<p>Copyright - ' . date("Y") . '</p>';
	$txt .= '</footer></div>';
	echo $txt;
?>