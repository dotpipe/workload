function callIndex() {
  var xhttp4 = new XMLHttpRequest();
  xhttp4.onreadystatechange = function() {
    if (xhttp4.readyState == 4 && xhttp4.status == 200) {
	document.getElementById("idAll").innerHTML = xhttp4.responseText;
	document.getElementById("showAll").style.display = 'block';
    }
  };
  var c = "PHP/workload.php";
  xhttp4.open("POST", c, true);
  xhttp4.send();
}

function callPHPHead(s, m, y, d) {
  var xhttp = new XMLHttpRequest();
  var pageID = 'showMo';
  if (s == "month") {
    pageID = 'showMo';
  }
  else if (s == "day") {
    pageID = 'showDay';
  }
  else if (s == "user") {
    pageID = 'showUser';
  }
  else if (s == "login") {
    pageID = 'showLogin';
  }
  else if (s == "sched") {
    pageID = 'showSched';
  }
  else if (s == "pass") {
    pageID = 'showPass';
  }
  else if (s == "notes") {
    pageID = 'showNotes';
  }
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
	if (s == "month") {
		document.getElementById("idUser").style.display = "none";
		document.getElementById("idMo").style.display = "none";
		document.getElementById("idMo").innerHTML = xhttp.responseText;
		document.getElementById("idMo").style.display = "block";
		document.getElementById("idPass").style.display = "none";
		document.getElementById("idDay").style.display = "none";
		document.getElementById("idLogin").style.display = "none";
		document.getElementById("idSched").style.display = "none";
		document.getElementById("idNotes").style.display = "none";
    	}
	else if (s == "notes") {
		document.getElementById("idUser").style.display = "none";
		document.getElementById("idMo").style.display = "none";
		document.getElementById("idNotes").style.display = "none";
		document.getElementById("idNotes").innerHTML = xhttp.responseText;
		document.getElementById("idNotes").style.display = "block";
		document.getElementById("idDay").style.display = "none";
		document.getElementById("idLogin").style.display = "none";
		document.getElementById("idSched").style.display = "none";
		document.getElementById("idPass").style.display = "none";
    	}
	else if (s == "pass") {
		document.getElementById("idUser").style.display = "none";
		document.getElementById("idMo").style.display = "none";
		document.getElementById("idPass").style.display = "none";
		document.getElementById("idPass").innerHTML = xhttp.responseText;
		document.getElementById("idPass").style.display = "block";
		document.getElementById("idDay").style.display = "none";
		document.getElementById("idLogin").style.display = "none";
		document.getElementById("idSched").style.display = "none";
		document.getElementById("idNotes").style.display = "none";
    	}
	else if (s == "day") {
		document.getElementById("idUser").style.display = "none";
		document.getElementById("idDay").style.display = "none";
		document.getElementById("idDay").innerHTML = xhttp.responseText;
		document.getElementById("idDay").style.display = "block";
		document.getElementById("idPass").style.display = "none";
		document.getElementById("idMo").style.display = "none";
		document.getElementById("idLogin").style.display = "none";
		document.getElementById("idSched").style.display = "none";
		document.getElementById("idNotes").style.display = "none";
    	}
	else if (s == "user") {
		document.getElementById("idUser").style.display = "none";
		document.getElementById("idDay").style.display = "none";
		document.getElementById("idUser").innerHTML = xhttp.responseText;
		document.getElementById("idUser").style.display = "block";
		document.getElementById("idPass").style.display = "none";
		document.getElementById("idMo").style.display = "none";
		document.getElementById("idLogin").style.display = "none";
		document.getElementById("idSched").style.display = "none";
		document.getElementById("idNotes").style.display = "none";
    	}
	else if (s == "login") {
		document.getElementById("idUser").style.display = "none";
		document.getElementById("idDay").style.display = "none";
		document.getElementById("idLogin").style.display = "none";
		document.getElementById("idLogin").innerHTML = xhttp.responseText;
		document.getElementById("idLogin").style.display = "block";
		document.getElementById("idPass").style.display = "none";
		document.getElementById("idMo").style.display = "none";
		document.getElementById("idSched").style.display = "none";
		document.getElementById("idNotes").style.display = "none";
    	}
	else if (s == "sched") {
		document.getElementById("idUser").style.display = "none";
		document.getElementById("idDay").style.display = "none";
		document.getElementById("idSched").style.display = "none";
		document.getElementById("idSched").innerHTML = xhttp.responseText;
		document.getElementById("idSched").style.display = "block";
		document.getElementById("idPass").style.display = "none";
		document.getElementById("idMo").style.display = "none";
		document.getElementById("idLogin").style.display = "none";
		document.getElementById("idNotes").style.display = "none";
    	}
    }
  };
  var x = "headers/";
  var c = "head.php?u="+pageID+"&m="+m+"&y="+y+"&d="+d;
  if (pageID == 'showDay') {
	c = "headday.php?u="+pageID+"&m="+m+"&y="+y+"&d="+d;
  }
  if (pageID == 'showUser') {
	c = "headuser.php?u="+pageID+"&m="+m+"&y="+y+"&d="+d;
  }
  if (pageID == 'showLogin') {
	c = "headlogin.php?u="+pageID+"&m="+m+"&y="+y+"&d="+d;
  }
  if (pageID == 'showSched') {
	c = "headsched.php?u="+pageID+"&m="+m+"&y="+y+"&d="+d;
  }
  if (pageID == 'showPass') {
	c = "headpass.php?u="+pageID+"&m="+m+"&y="+y+"&d="+d;
  }
  if (pageID == 'showNotes') {
	c = "headnotes.php?u="+pageID+"&m="+m+"&y="+y+"&d="+d;
  }
  xhttp.open("POST", x+c, true);
  xhttp.send();
  callPHPScript(s+".php",m,y,d);
}

function callPHPScript(url, m, y, d) {
  var xhttp1 = new XMLHttpRequest();
  xhttp1.onreadystatechange = function() {
    if (xhttp1.readyState == 4 && xhttp1.status == 200) {
	if (url == "month.php") {
		document.getElementById("showMo").innerHTML = xhttp1.responseText;
	}
	else if (url == "day.php") {
		document.getElementById("showDay").innerHTML = xhttp1.responseText;
	}
	else if (url == "user.php") {
		document.getElementById("showUser").innerHTML = xhttp1.responseText;
	}
	else if (url == "login.php") {
		document.getElementById("showLogin").innerHTML = xhttp1.responseText;
	}
	else if (url == "sched.php") {
		document.getElementById("showSched").innerHTML = xhttp1.responseText;
	}
	else if (url == "pass.php") {
		document.getElementById("showPass").innerHTML = xhttp1.responseText;
	}
	else if (url == "notes.php") {
		document.getElementById("showNotes").innerHTML = xhttp1.responseText;
	}
    }
  };
  var c = "PHP/"+url+"?m="+m+"&y="+y+"&d="+d;
  xhttp1.open("POST", c, true);
  xhttp1.send();
  //listMySched();
}


function callLogger() {
  var xhttp2 = new XMLHttpRequest();
  xhttp2.onreadystatechange = function() {
    if (xhttp2.readyState == 4 && xhttp2.status == 200) {
	document.getElementById("showLog").innerHTML = xhttp2.responseText;
	document.getElementById("showLog").style.display = 'block';
    }
  };
  c = "functions/backlog.php";
  xhttp2.open("POST", c, true);
  xhttp2.send();
}

function deactiveDate(indx) {
  var xhttp2 = new XMLHttpRequest();
  c = "PHP/serverside.php?deactive_date=1&n="+indx;
  xhttp2.open("POST", c, true);
  xhttp2.send();
}

function activeDate(indx) {
  var xhttp2 = new XMLHttpRequest();
  c = "PHP/serverside.php?active_date=1&n="+indx;
  xhttp2.open("POST", c, true);
  xhttp2.send();
}

function deactiveUser(indx) {
  var xhttp2 = new XMLHttpRequest();
  c = "PHP/serverside.php?deactive_user=1&n="+indx;
  xhttp2.open("POST", c, true);
  xhttp2.send();
}

function activeUser(indx) {
  var xhttp2 = new XMLHttpRequest();
  c = "PHP/serverside.php?active_user=1&n="+indx;
  xhttp2.open("POST", c, true);
  xhttp2.send();
}

function addUser() {
  var xhttp2 = new XMLHttpRequest();
  xhttp2.onreadystatechange = function() {
    if (xhttp2.readyState == 4 && xhttp2.status == 200) {
	document.getElementById("showLog").innerHTML = xhttp2.responseText;
	document.getElementById("showLog").style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?add_users_func=1";
  xhttp2.open("POST", c, true);
  xhttp2.send();
}

function removeUser() {
  var xhttp2 = new XMLHttpRequest();
  xhttp2.onreadystatechange = function() {
    if (xhttp2.readyState == 4 && xhttp2.status == 200) {
	document.getElementById("showLog").innerHTML = xhttp2.responseText;
	document.getElementById("showLog").style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?rem_users_func=1";
  xhttp2.open("POST", c, true);
  xhttp2.send();
}

function addDate() {
  var xhttp2 = new XMLHttpRequest();
  xhttp2.onreadystatechange = function() {
    if (xhttp2.readyState == 4 && xhttp2.status == 200) {
	document.getElementById("showLog").innerHTML = xhttp2.responseText;
	document.getElementById("showLog").style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?add_date_func=1";
  xhttp2.open("POST", c, true);
  xhttp2.send();
}

function removeDate() {
  var xhttp2 = new XMLHttpRequest();
  xhttp2.onreadystatechange = function() {
    if (xhttp2.readyState == 4 && xhttp2.status == 200) {
	document.getElementById("showLog").innerHTML = xhttp2.responseText;
	document.getElementById("showLog").style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?rem_date_func=1";
  xhttp2.open("POST", c, true);
  xhttp2.send();
}

function listMySched() {
  var xhttp3 = new XMLHttpRequest();
  xhttp3.onreadystatechange = function() {
    if (xhttp3.readyState == 4 && xhttp3.status == 200) {
	document.getElementById("idListSched").innerHTML = xhttp3.responseText;
	document.getElementById("showListSched").style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?whois=1";
  xhttp3.open("POST", c, true);
  xhttp3.send();
}

function listSched() {
  var xhttp3 = new XMLHttpRequest();
  xhttp3.onreadystatechange = function() {
    if (xhttp3.readyState == 4 && xhttp3.status == 200) {
	document.getElementById("idSched").innerHTML = xhttp3.responseText;
	document.getElementById("showSched").style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?whois_side=1";
  xhttp3.open("POST", c, true);
  xhttp3.send();
}

function addNote() {
  var xhttp3 = new XMLHttpRequest();
  xhttp3.onreadystatechange = function() {
    if (xhttp3.readyState == 4 && xhttp3.status == 200) {
	document.getElementById("idNote").innerHTML = xhttp3.responseText;
	document.getElementById("showNote").style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?add_note_func=1";
  xhttp3.open("POST", c, true);
  xhttp3.send();
}

function listNotes() {
  var xhttp4 = new XMLHttpRequest();
  xhttp4.onreadystatechange = function() {
    if (xhttp4.readyState == 4 && xhttp4.status == 200) {
	document.getElementById("idNotes").innerHTML = xhttp4.responseText;
	document.getElementById("showNotes").style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?listing_notes=1";
  xhttp4.open("POST", c, true);
  xhttp4.send();
}

function listSideNotes() {
  var xhttp4 = new XMLHttpRequest();
  xhttp4.onreadystatechange = function() {
    if (xhttp4.readyState == 4 && xhttp4.status == 200) {
	document.getElementById("idSideNotes").innerHTML = xhttp4.responseText;
	document.getElementById("showSideNotes").style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?listing_side_notes=1";
  xhttp4.open("POST", c, true);
  xhttp4.send();
}

function readNote(m) {
  var xhttp4 = new XMLHttpRequest();
  xhttp4.onreadystatechange = function() {
    if (xhttp4.readyState == 4 && xhttp4.status == 200) {
	document.getElementById('idNotes').innerHTML = xhttp4.responseText;
	document.getElementById('showNotes').style.display = 'block';
    }
  };
  var c = "PHP/serverside.php?read_notes="+m;
  xhttp4.open("POST", c, true);
  xhttp4.send();
}

setInterval(function() {
	listSideNotes();
	callLogger();
}, 2500)