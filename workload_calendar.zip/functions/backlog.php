<?php
	require("../php/serverside.php");
	require("../php/startup.php");
	$logconn = new mysqli('localhost:3306','root','!3$!3$','dbs8105296');
	if ($logconn->connect_error) die($conn->error);
	$temp = '';
	$result = array();
	if ($users->adm == "on") {
		$dbquery = 'SELECT * FROM logdb WHERE GROUP_NO <= "' . $users->usrgrp . '"';
		$result = $logconn->query($dbquery);
		if (!$result) echo "Log failure: $query<br>" .
			$logconn->error . "<br/><br/>";
		else reset($_GET);
		$rows = $result->num_rows;
		echo '<table style="border:1px solid black;width:200">';
		echo '<tr><td style="border-bottom:1px black dotted;font-size:12;background:tan">Error Log</td></tr>';
		for ($x = $rows - 1 ; $x >= $rows - 5; $x--) {
			$result->data_seek($x);
			$client = $result->fetch_array(MYSQLI_NUM);
			$temp .='<tr>';
			if ($client[0] == "Success") {
				$temp .= '<td style="border-bottom:1px black dotted;font-size:12;';
				$temp .= 'background-color:darkgreen">';
				$temp .= $client;
				$temp .= '</td>';
			}
			else if ($client[0] == "Fail") {
				$temp .= '<td style="border-bottom:1px black dotted;font-size:12;';
				$temp .= 'background-color:red">';
				$temp .= $client;
				$temp .= '</td>';
			}
			else {
				$temp .= '<td style="border-bottom:1px black dotted;font-size:12;">';
				$temp .= $client;
				$temp .= '</td>';
			}
			$temp .= '</tr>';
		}
		$temp .= '</table>';
		echo $temp;
	}
	else {
		$result = '';
		$temp = '';
		$dbquery = 'SELECT * FROM logdb WHERE USER = "' . $users->uname . '"';
		$result = $logconn->query($dbquery);
		if (!$result) echo "Log failure: " .
			$logconn->error . "<br/><br/>";
		else reset($_GET);
		$rows = $result->num_rows;
		echo '<table style="border:1px solid black;width:200">';
		echo '<tr><td style="border-bottom:1px black dotted;font-size:12;background:tan">Error Log</td></tr>';
		$x = 0;
		for ($x = $rows ; $x >= $rows - 5; $x--) {
			$result->data_seek($x);
			$client = $result->fetch_array(MYSQLI_NUM);
			$temp .='<tr>';
			if ($client == "Success") {
				$temp .= '<td style="border-bottom:1px black dotted;font-size:12;';
				$temp .= 'background-color:darkgreen">';
				$temp .= $client;
				$temp .= '</td>';
			}
			else if ($client == "Fail") {
				$temp .= '<td style="border-bottom:1px black dotted;font-size:12;';
				$temp .= 'background-color:red">';
				$temp .= $client;
				$temp .= '</td>';
			}
			else {
				$temp .= '<td style="border-bottom:1px black dotted;font-size:12;">';
				$temp .= $client;
				$temp .= '</td>';
			}
			$temp .= '</tr>';
		}
		$temp .= '</table>';
		echo $temp;
	}
	$logconn->close();
?>