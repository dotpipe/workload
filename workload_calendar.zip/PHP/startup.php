<script src="/js/scripts.js"></script>
<?php
require_once("serverside.php");

		class Profiles {
			public $background;
			public $textcolor;
		}

		$profile = new Profiles();

		if(isset($_GET['color'])) { $profile->background = $_GET['color']; } //
		else $profile->background = "white";
		if(isset($_GET['usr'])) { $users->uname = $_GET['usr']; } //
		if(isset($_GET['pw'])) { $users->password = $_GET['pw']; } //
		if(isset($_GET['moduser'])) { $users->moduser = $_GET['moduser']; } //
		if(isset($_GET['modgrp'])) { $users->modgrp = $_GET['modgrp']; } //
		if(isset($_GET['grp'])) { $users->usrlvl = $users->usrgrp = $_GET['grp']; } //
		if(isset($_GET['email'])) { $users->email = $_GET['email']; } //
		if(isset($_GET['singular'])) { $dates->singular = $_GET['singular']; } //
		if(isset($_GET['y'])) { $dates->year = $_GET['y']; } //
		if(isset($_GET['m'])) { $dates->month = $_GET['m']; } //
		if(isset($_GET['d'])) { $dates->day = $_GET['d']; } //
		if(isset($_GET['dy'])) { $dates->year = $_GET['dy']; } //
		if(isset($_GET['dm'])) { $dates->month = $_GET['dm']; } //
		if(isset($_GET['vacation'])) { $dates->vacation = $_GET['vacation']; } //
		if(isset($_GET['perm'])) { $dates->perm = $_GET['perm']; } //
		if(isset($_GET['length'])) { $dates->length = $_GET['length']; } //
		if(isset($_GET['dtls'])) { $dates->dtls = $_GET['dtls']; } //
		if(isset($_GET['all'])) { $dates->all = $_GET['all']; } //
		if(isset($_GET['inpw'])) { $logins->password = $_GET['inpw']; } //
		if(isset($_GET['inusr'])) { $logins->uname = $_GET['inusr']; } //
		if(isset($_GET['idx'])) { $users->indx = $_GET['idx']; } //
		if(isset($_GET['is_admin'])) { $users->adm = $_GET['is_admin']; } //
		if(isset($_GET['set_admin'])) { $users->setadm = $_GET['set_admin']; } //
		if(isset($_GET['recp'])) { $notes->to = $_GET['recp']; } //
		if(isset($_GET['dtls'])) { $users->desc = $_GET['dtls']; } //
		if(isset($_GET['begin'])) { $dates->begin = $_GET['begin']; } //
		if(isset($_SERVER['HTTP_ORIGIN'])) {
			$domaintok = md5("DfOdd@f" . $_SERVER['HTTP_ORIGIN'] . "sD1o0J");
			$users->utoken = $domaintok;
		} //
?>