<?php
	require("serverside.php");

	$URL = "showMo";
	global $dy;
	$dy = date("j");
	global $mo;
	$mo = date("m");
	global $Yr;
	$Yr = date("Y");
	if(! isset($Yr)) { $Yr = date("Y"); }
	if(isset($_GET['m'])) { $mo = $_GET['m']; }
	if(isset($_GET['y'])) { $Yr = $_GET['y']; }
	if(! isset($_GET['d'])) { $dy = 1; }
	echo '<table style="vertical-align:top" border=1 width="50%" cellpadding="3"><tr><td>';
			echo '<form method="POST">';
			echo '<table style="text-align:top;width:500" cellpadding="3"><tr>';
			echo '<td style="cursor:default;width:20%">Method of Lookup</td>';
			echo '<td style="cursor:default">Username</td></tr>';
			echo '<tr><td><input type="hidden" value="1" name="whois">';
			echo '<input type="radio" name="who_lookup" required="required" checked="checked" value="0"/> Self ';
			if ($users->adm != "on")
				$disstrict = ' disabled';
			else $disstrict = '';
			echo '<input type="radio"' . $disstrict . ' name="who_lookup" value="1"/> User ';
			echo '<input type="radio"' . $disstrict . ' name="who_lookup" value="2"/> Group ';
			echo '</td><td colspan=1><input style="width:190"' . $disstrict . ' name="user_sched" type="textbox"></td><td></td><td></td></tr><td>Group</td><td>Starting Date</td></tr>';
			echo '<td><input name="group" min="0"' . $disstrict . ' type="number"></td>';
			echo '<td><input name="begin" type="date" required="required"></td>';
			echo '<td style="text-align:left;"><button style="border:1px solid black" type="submit">';
			echo 'Submit</button></td></tr>';
			echo '</table>';
	$dates->listSchedule($users);
	echo '</td></tr></table>';

?>