<?php
	require("serverside.php");
	require("startup.php");
	$URL = "showMo";
	global $dy;
	$dy = date("j");
	global $mo;
	$mo = date("m");
	global $Yr;
	$Yr = date("Y");
	if(! isset($Yr)) { $Yr = date("Y"); }
	if(isset($_GET['m'])) { $mo = $_GET['m']; }
	if(isset($_GET['y'])) { $Yr = $_GET['y']; }
	if(isset($_GET['d'])) { $dy = 1; }
		if ($users->adm != "on")
			$disstrict = ' disabled';
		else $disstrict = '';
	echo '<form method="POST">';
	echo '<center>';
	echo '<table style="text-align:top;width:500" border=1 cellpadding="3"><tr>';
	echo '<input type="hidden" name="group" value="' . $users->usrlvl . '"/>';
	echo '<td style="cursor:default;width:35%">Recipient</td><td></td></tr>';
	echo '<td style="border-top:1px dotted black;border-right:1px dotted black;border-left:1px dotted black;"><input type="textbox" style="width:200" name="recp" required/></td></tr>';
	echo '<tr><td rowspan=2 style="border-left:1px black dotted;border-right:1px black solid;border-bottom:1px black dotted;"><textarea style="height:150;width:200" name="dtls" value="note" required>Note Details</textarea></td>';
	echo '<td style="border-top:1px dotted black;font-size:32px;"><button onclick="addNote()" type="submit" style="border:0px;color:green;background-color:white;">+</button><span style="font-size:24px"> Send Note</span></td></tr>';
	echo '<tr><td style="border-top:1px dotted black;font-size:32px;padding-left:11px"><span style="border:0px;color:black;background-color:white;cursor:pointer;border-right:1px" onclick=' . 'callPHPHead("month",' . $mo . ',' . $Yr . ',1)>x</span><span style="font-size:24px;padding-left:10px"> Cancel Note</span></td></tr>';
	echo '<tr><td style="text-align:center;border-bottom:1px black dotted;text-align:center"><input type="checkbox"' . $disstrict . ' name="admins"/> Only Admins</td>';
	echo '<td style="text-align:center;color:red;border-bottom:1px dotted black"> <input type="checkbox"' . $disstrict . ' name="all"/> All Users</form></td>';
	echo '</tr></table></center>';

		if ($users->flag != 1) {
			throwError("Logged Out");
			return;
		}
		$dbquery = 'SELECT DATE, SNDER, RCPT, DETAILS, ID, ADMINS_EYES, ADMIN_MADE FROM notes WHERE USER = ';
		$client = array ($dbquery, "afd"); //,"sadg","Affrg","dgsoi","dalfj");
		if ($data->adm == "on")
			$dbquery .= ' AND ADMINS = 1';
		else
			$dbquery .= ' AND ADMINS = "ON"';
		$dbquery .= ' AND READ = 0';
		$dbquery .= ' AND TOKEN = "' . $data->utoken . '"';
		$client = $conn->query(dbquery);
		$rows = $client->num_rows;
		$temp = '<table style="cursor:default;font-size:12px;">';
		$temp .= '<tr><td></td><td></td><td></td><td></td><td></td></tr><tr>';
		$x = 0;
		for ($x = 0 ; $x < rows ; $x++) {
			$client->data_seek($x);
			$row = $client->fetch_array(MYSQLI_NUM);
			$temp .= '<td style="width:15%;border:10px white solid;vertical-align:baseline;">';
			$temp .= '<table><tr>';
			$temp .= '<td colspan="2" style="vertical-align:baseline;border-top:1px black solid;border-left:1px black solid;border-right:1px black solid;cursor:default;">' . $row[0] . '</td></tr><tr>';
			for ($j = 1; $j < 3; $j++) {
				$temp .= '<td style="border-left:1px black solid;border-right:1px black solid;cursor:default;">';
				$temp .= $row[$j];
				$temp .= '</td>';
			}
			$temp .= '</tr><tr>';
			$temp .= '<td colspan="2" style="border-left:1px black solid;border-right:1px black solid;cursor:default;">' . $row[3];
			$temp .= '</td></tr>';
			if ($row[5] == "1" && $data->adm == "on")
				$temp .= '<tr><td colspan=2 style="border-top:1px black dotted;font-size:12;color:red;text-align:right">Admins Only</td></tr>';
			if ($row[6] != "0")
				$temp .= '<tr><td colspan=2 style="border-top:1px black dotted;font-size:12;color:red;text-align:right">From Admin</td></tr>';

			$temp .= '<tr><td colspan=2 style="border-top:1px black dashed;color:red;font-size:12;text-align:right">';
			$temp .= '<span onclick=' . 'readNote(' . $row[4] . ')>';
			$temp .= 'Mark Read</span></td></tr></table></td>';
			if ($x%5 == 0) {
				$temp .= '</tr>';
			if ($x + 1 < $rows)
				$temp .= '<tr>';
			}
		}
		$temp .= '</table>';
		echo $temp;

?>