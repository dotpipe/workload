﻿<script src="../js/scripts.js"></script>

<?php
	// Populate by JSON API
	// Login with User/Token
	// Get JSON by Running
	// User->fget_contents()
	// with base URL of client
	// --------------
	// fget_contents thru Dated
	// Date->fget_contents()
	// goes to Date->loadfromJSON()
	// --------------
	// Use variables of Dated to
	// Add/Remove/List Scheduling
	// Done.

	$conn = new mysqli('localhost:3306','root','!3$!3$','dbs8105296');
	$results = array();
	function throwError($err) { echo 'Error Logged: ' . $err . '<br/>'; }

	class Note {
		public $date;
		public $desc;
		public $to;
		public $from;
		public $read;
		public $utoken;
	}

	class Logger {
		public $user;	
		public $results;
		public $attr;
		public $date;
		public $utoken;
		public $group;

		static function logAll($data) { 
			$data->base_url = $_SERVER['REMOTE_HOST'];
			$dbquery = 'INSERT INTO logdb VALUES (NULL,"' . $data->result . '","' . $data->attr . '",';
			$dbquery .= 'NULL,"' . $logins->group . '","' . $data->base_url . '","' . $data->utoken . '","';
			$dbquery .= $data->user . '");';
			$results = $conn->query($dbquery);
			if (!$results) { 
				echo "Log failure: " .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_GET);
		}
	}

	class Login {
		public $indx;
		public $uname;
		public $password;
		public $group;
		public $utoken;
		public $base_url;
		public $flag;
		public $users;
	}

	class UserData {
		public $indx;
		public $uname;
		public $password;
		public $usrlvl;
		public $usrgrp;
		public $utoken;
		public $adm;
		public $flag;
		public $base_url;
		public $email;
	}

	class Dated {
		//DBQuery
		public $dbquery;
		public $result;
		// String
		public $dtls;
		// Calendar Functioning
		public $yr;
		public $mo;
		// Real
		public $day;
		public $month;
		public $year;
		public $length;
		// On, Off
		public $singular;
		public $vacation;
		// Time (24 hr)
		public $start;
		public $end;
		//User Info
		public $indx;
		public $user_sched;
		public $utoken;
		//JSON Array
		public $jsonarr;
		public $json_enc;

		public function loadfromJSON($json) {
			$object = json_decode($json);
			foreach($object AS $name => $val) {
				$this->{$name} = $val;
			}
		}

//
		public function addDate($data) {
			if ($data->flag == 0) {
				throwError("Logged Out");
				return;
			}
			$try = new Logger();
			// * made for smart phones, watches, future stuff
			// $length is a length of days, not a date
			// use $day,$month,$year w/ or w/o $length
			// based on $multi boolean. Cross ref $vacation.
			// $start,$end are times to begin and end event.
			// $name is event. $dtls is details. $uname is for users
			// there may be > 1 events per day. Inc. vacations.

			// query to add multi day event (not a leave)
			// use $day,$month,$year,$name,$dtls for 1st date
			// use $length for last date.
			// $users->uname for multi-user experience:
			// admin gets full list of events
			$dbquery = 'INSERT INTO schedule ';
			$dbquery .= 'VALUES (NULL,"' . $data->utoken . '","' . $this->timea . '","' . $this->timez . '","' . $this->singular;
			$dbquery .= '","' . $this->date . '","' . $this->dtls . '","' . $data->uname . '","' . $data->usrlvl . '","' . $this->length . '","1","' . $data->whom . '");';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Entry Error &lt;Schedule&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_GET);
			if ($results) {
				$try->result = "Success";
				$try->attr = "Add Date"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else { 
				throwError("Add Date Denied"); $try->result = "Fail";
				$try->attr = "Add Date"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			Logger::logAll($try);
			
		}

		public function deactivateDate($data) {
			$try = new Logger();
			$dbquery = 'UPDATE schedule SET ACTIVE = "0", ACTION = "' . $data->uname . '" WHERE ID = "' . $data->indx;
			if ($data->adm == "on" && ! isset($data->whom))
				$dbquery .= '" AND GROUP_NO == "' . $data->usrgrp . '";';
			else 
				$dbquery .= '" AND USERNAME = "' . $data->whom . '";';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Remove Error &lt;Schedule&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_GET);
			if ($results) {
				$try->result = "Success";
				$try->attr = "Deactivate Date"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else { 
				throwError("Denied Removal"); $try->result = "Fail";
				$try->attr = "Deactivate Date"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
		}

		public function activateDate($data) {
			$try = new Logger();
			$dbquery = 'UPDATE schedule SET ACTIVE = "1", ACTION = "' . $data->uname . '" WHERE ID = "' . $data->indx;
			if ($data->adm == "on" && ! isset($data->whom))
				$dbquery .= '" AND GROUP_NO = "' . $data->usrlvl . '";';
			else 
				$dbquery .= '" AND USERNAME = "' . $data->uname . '";';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Remove Error &lt;Schedule&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_GET);
			if ($results) {
				$try->result = "Success";
				$try->attr = "Deactivate Date"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else { 
				throwError("Denied Removal"); $try->result = "Fail";
				$try->attr = "Deactivate Date"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
		}

//
		public function removeDate($data) {
			if (! isset($data->flag) || $data->flag != "1") {
				throwError("Logged Out");
				return;
			}
			$try = new Logger();
			// Use $this to delete
			// from calendar db rows
			// delete hash file w/ dtls
			$dbquery = 'DELETE FROM schedule ';
			$dbquery .= 'WHERE ID = "' . $data->indx . '" AND (USERNAME = "' . $data->uname . '"';
			if ($data->adm == "on")
				$dbquery .= ' OR GROUP_NO = ' . $data-usrlvl;
			$dbquery .= ');';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Remove Error &lt;Schedule&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_GET);
			if ($results) {
				$try->result = "Success";
				$try->attr = "Remove Date"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else { 
				throwError("Denied Removal"); $try->result = "Fail";
				$try->attr = "Remove Date"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			Logger::logAll($try);
		}
//
		public function listMySchedule($data) {

			$try = new Logger();
			if (! isset($data->flag) || $data->flag != "1") {
				throwError("Logged Out");
				return;
			}
			// Get list of events
			// from date queried
			// list in table in day.php
			// radio inputs beside events
			// must be named for index
			$dbquery = 'SELECT DATE, START, END, LEN, DETAILS, ID FROM schedule ';
			$dbquery .= 'WHERE USERNAME = "' . $data->uname . '" OR GROUP_NO = ' . $data->usrgrp . ';';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Listing Error &lt;Schedule&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_GET);
			$rows = $results->num_rows;
			$temp = '<table style="width:200;border:1px black solid;font-size:12px;">';
			$y = 5;
			if ($rows > 5) $y= 5;
			else $y = $rows;
			for ($x = 0; $x < $rows; $x++) {
				$results->data_seek($x);
				$row = $results->fetch_array(MYSQLI_NUM);
				$temp .= '<tr><td>' . $row[0] . '</td></tr><tr>';
				for ($j = 1; $j < 3; $j++) {
					$temp .= '<td>' . $row[$j];
					$temp .= '</td>';
				}
				$temp .= '</tr>';
				$temp .= '<tr><td colspan=3>' . $row[3];
				$temp .= '</td></tr>';
				$temp .= '<tr><td colspan=3>' . $row[4];
				$temp .= '</td><td style="text-align:right" colspan=3>';
				$temp .= '<span onclick=' . 'removeDate(' . $row[5] . ')>';
				$temp .= 'Remove Date</span></td></tr>';
			}
			$temp .= '</table>';

			$x = 0;
			foreach ($results AS $pez) {
				$this->jsonarr[] = $pez;
			}

			$this->json_enc = json_encode($this->jsonarr);

			if ($results) { $try->result = "Success";
				$try->attr = "List Schedule";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else {
				throwError("List Schedule Denied"); $try->result = "Fail";
				$try->attr = "List Schedule";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			Logger::logAll($try);
			return $this->json_enc;
		}

// 
		public function listSchedule($data) {
			$try = new Logger();
			if (! isset($data->flag) || $data->flag != "1") {
				throwError("Logged Out");
				return;
			}
			$conn = new mysqli('localhost:3306','root','!3$!3$','dbs8105296');
			$sched = $_GET['user_sched'];
			// Get list of events
			// from date queried
			// list in table in day.php
			// radio inputs beside events
			// must be named for index
			$dbquery = 'SELECT * FROM schedule ';
			$dbquery .= 'WHERE (LEN >= "' . date("Y-m-j") . '" OR ACTIVE = "1")';
			$dbquery .= ' AND GROUP_NO = "' . $data->usrlvl . '";';
			// My Schedule = 0 // User Schedule = 1 // Group Sched = 2
			if ($_GET['who_lookup'] == 0)
				$dbquery .= ' USERNAME = "' . $data->uname . '"';
			else if ($_GET['who_lookup'] == 1)
				$dbquery .= ' USERNAME = "' . $data->whom . '"';
			else if ($_GET['who_lookup'] == 2 && $_GET['group'] = $data->usrgrp)
				$dbquery .= ' GROUP_NO = "' . $data->usrgrp . '"';
			$dbquery .= ' AND TOKEN = "' . $data->utoken . '";';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Listing Error &lt;Schedule&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_GET);
			$rows = $results->num_rows;
			$temp = '<table style="border:1px black solid;font-size:12px;">';

			for ($x = 0; $x < $rows; $x++) {
				$results->data_seek($x);
				$row = $results->fetch_array(MYSQLI_NUM);
				$temp .= '<tr>';
				$temp .= '<table><tr>';
				for ($j = 3; $j < 5; $j++) {
					$temp .= '<td>&nbsp;';
					$temp .= $row[$j];
					$temp .= '</td>';
				}
				$temp .= '</tr>';
				$temp .= '<tr><td>' . $row[4];
				$temp .= '</td></tr><tr><td colspan=2 style="font-size:12px">' . $row[6];
				$temp .= '</tr><tr><td>' . $row[10] . '</td><td>' . $row[9] . '</td></tr>';
				if (row[10] == "1") {
					$temp .= '<tr><td style="color:red" onclick=' . 'deactiveDate(' . $row[0] .')';
					$temp .= 'colspan=2>Deactivate</td></tr>';
				}
				else {
					$temp .= '<tr><td style="color:red" onclick=' . 'activeDate(' . $row[0] .')';
					$temp .= 'colspan=2>Activate</td></tr>';
				}
				if ($x%5 == 0 || $x + 1 == $rows)
					$temp .= '</tr>';
			}
			$temp .= '</table>';
			echo $temp;

			if ($results) {
				$try->result = "Success";
				$try->attr = "List Schedule";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else { 
				throwError("Schedule Denied"); $try->result = "Fail";
				$try->attr = "List Schedule";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			Logger::logAll($try);
		}
	}

	class User {
		//Admin Responsibilities
		public $newpassw;
		public $newuser;
		public $repassw;
		//DBQuery
		public $dbquery;
		public $result;
		//Internals
		public $usrgrp;
		public $usrlvl;
		public $moduser;
		public $modgrp;
		public $password;
		public $uname;
		public $base_url;
		public $email;
		public $indx;
		public $adm;
		public $setadm;
		public $flag;
		public $utoken;
		public $whom;
		//JSON Array
		public $jsonarr;

		public function deactivateUser($data) {
			if ($data->adm != "on") { 
				throwError("Deactivate Denied"); $try->result = "Fail";
				$try->attr = "Deactivate User"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			$dbquery = 'UPDATE user SET ACTIVE = "0", ACTION = "' . $data->uname . '" WHERE ID = "' . $data->indx;
			if ($data->adm == "on")
				$dbquery .= '" AND GROUP_NO = "' . $data->usrlvl . '";';
			else 
				$dbquery .= '" AND USERNAME = "' . $data->moduser . '";';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Remove Error &lt;Schedule&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_GET);
			if ($results) {
				$try->result = "Success";
				$try->attr = "Deactivate User"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else { 
				throwError("Deactivate Denied"); $try->result = "Fail";
				$try->attr = "Deactivate User"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
		}

		public function activateUser($data) {
			if ($data->adm != "on") { 
				throwError("Deactivate Denied"); $try->result = "Fail";
				$try->attr = "Deactivate User"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			$dbquery = 'UPDATE user SET ACTIVE = "1", ACTION = "' . $data->uname . '" WHERE ID = "' . $data->indx;
			if ($data->adm == "on")
				$dbquery .= '" AND GROUP_NO = "' . $data->usrlvl . '";';
			else 
				$dbquery .= '" AND USERNAME = "' . $data->moduser . '";';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Remove Error &lt;Schedule&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_GET);
			if ($results) {
				$try->result = "Success";
				$try->attr = "Deactivate User"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else { 
				throwError("Deactivate Denied"); $try->result = "Fail";
				$try->attr = "Deactivate User"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
		}
//
		public function modifyUsr($data) {
			$try = new Logger();
			if (! isset($data->flag) || $data->flag != "1") {
				throwError("Logged Out");
				return;
			}

			if ($data->adm != "on") {
				throwError("You do not have adequate permissions"); $try->result = "Fail";
				$try->attr = "Modify User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
				Logger::logAll($try);
				return;
			}

			$dbquery = 'SELECT USERNAME, ID, GROUP_NO FROM user WHERE USERNAME = "' . $data->moduser . '"';
			$dbquery .= ' AND TOKEN = "' . $data->utoken . '";';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Modify Error &lt;User&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_GET);
			$rows = $results->num_rows;
			$results->data_seek(0);
			$row = $results->fetch_array(MYSQLI_NUM);
			if ($row[0] != $data->moduser) {
				throwError("User Does Not Exist");
				$try->result = "Fail";
				$try->attr = "Modify User"; $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
				Logger::logAll($try);
				return;
			}
			else {
				$reset($dbquery1);
				if ($row[2] <= $data->usrgrp && $data->modgrp <= $data->usrgrp) {
					if (isset($data->modgrp)) {
						$dbquery1 .= ' GROUP_NO = ' . $data->modgrp;
					}
					if (isset($data->email)) {
						if (isset($dbquery1))
							$dbquery1 .= ',';
						$dbquery1 .= ' EMAIL = "' . $data->email;
					}
					if (isset($data->newpassw)) {
						if (isset($dbquery1))
							$dbquery1 .= ',';
						$dbquery1 .= ' PASSWORD = ' . $data->newpassw;
					}
					if (isset($data->is_admin)) {
						if (isset($dbquery1))
							$dbquery1 .= ',';
						$dbquery1 .= ' ADMIN = ' . $data->is_admin;
					}
					$dbquery .= ' WHERE USERNAME = ' . $data->moduser;
					$results = $conn->query($dbquery);
					if (!$results) echo "Modify User Error: " .
						$conn->error . "<br/><br/>";
					else reset($_GET);
				}
				else { throwError("You do not have adequate permissions"); $results = ""; }

				if ($results) {
					$try->result = "Success";
					$try->attr = "Modify User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
					$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
				}
				else { 
					throwError("You do not have adequate permissions"); $try->result = "Fail";
					$try->attr = "Modify User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
					$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
				}
				Logger::logAll($try);
			}
		}

//
		public function switchUser($data, $lvl) {
			if (! isset($data->flag) || $data->flag != "1") {
				throwError("Logged Out");
				return;
			}

			if ($data->adm != "on") {
				throwError("You do not have adequate permissions"); $try->result = "Fail";
				$try->attr = "Switch User Level";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
				Logger::logAll($try);
				return;
			}
			$try = new Logger();

			if ($data->usrgrp >= $lvl)
				$data->usrlvl = $lvl;
			else { throwError("User Level Too High"); }
			
			if ($data->usrlvl == $lvl) {
				$try->result = "Success";
				$try->attr = "SU Level";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else { 
				throwError("You do not have adequate permissions"); $try->result = "Fail";
				$try->attr = "SU Level";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			Logger::logAll($try);
		}

//
		public function loadfromJSON($json) {
			$object = json_decode($json);
			foreach($object AS $name => $val) {
				$this->{$name} = $val;
			}
		}

//
		public function get_client_id($data) {
			$try = new Logger();

			// Get $results (username) query from db
			// get index from db
			$dbquery = 'SELECT USERNAME, TOKEN, GROUP_NO, ADMIN FROM user ';
			$dbquery .= 'WHERE USERNAME = "' . $data->uname . '" AND TOKEN = "' . $data->utoken . '";';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Login Error &lt;Step 2&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_GET);
			$results->data_seek(0);
			$row = $results->fetch_array(MYSQLI_NUM);
			if ($data->uname == $row[0]) {
				$data->uname = $row[0];
				$data->group = $row[2];
				if ($row[3])
					$data->adm = "on";
				else $data->adm = 0;
				$data->flag = 1;
				if ($data->utoken == $row[1])
					$data->flag = 2;
			}
			else { $data->flag = 0; }

			if ($data->flag == 1) {
				$try->result = "Success";
				$try->attr = "Getting Attributes";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else if ($data->flag == 2) {
				throwError("Invalid Login"); $try->result = "Fail";
				$try->attr = "Granting Token Access";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			else {
				throwError("Invalid Login"); $try->result = "Fail";
				$try->attr = "Getting Attributes";  $try->base_url = $_SERVER['REMOTE_ADDR'];
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			}
			Logger::logAll($try);
		}

		function listUsers() {
			if (! isset($this->flag) || $this->flag != "1") {
				throwError("Logged Out");
				return;
			}

			$dbquery = 'SELECT ID, USERNAME, GROUP_NO, EMAIL, LAST, ADMIN FROM user WHERE TOKEN = "' . $this->utoken . '";';
			$results = $conn->query($dbquery);
			if (!$results) {
				echo "Listing Error &lt;Users&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_GET);
			$temp = $results->num_rows . ' Users Returned';
			$temp = '<table style="cursor:default;border:1px black solid;font-size:12px;">';
			$temp .= '<tr><td>USER</td><td>GROUP_NO</td><td>EMAIL</td><td>LAST</td><td>ADMIN</td></tr>';
			$rows = $results->num_rows;
			for ($x = 0; $x < $rows; $x++) {
				$results->data_seek($x);
				$row = $results->fetch_array(MYSQLI_NUM);
				$temp .= '<tr>';
				$temp .= '<form method="POST">';
				$temp .= '<input type="hidden" name="idx" value="' . $row[0] . '"/>';
				for ($j = 1; $j < 4; $j++) {
					$temp .= '<td style="text-align:left">';
					$temp .= $row[$j];
					$temp .= '</td>';
				}
				$temp .= '<td style="border-bottom:1px black dashed;color:red;text-align:right">';
				$temp .= '<button ';
				if ($row[2] >= $this->usrlvl && $this->adm != "on")
					$temp .= 'disabled ';
				$temp .= 'style="border:0px;" type="submit" onclick=' . 'removeUser(' . $row[0] . ')>';
				$temp .= 'Remove User</button></form></td></tr>';
				$temp .= '<td style="border-bottom:1px black dashed;color:red;text-align:right">';
				if ($row[2] <= $this->usrgrp && $this->adm == "on") {
					if ($row[9] == 1) {
						$temp .= '<form method="POST"><button style="border:0px;" type="submit" onclick=' . 'deactiveUser(' . $row[0] . ')>';
						$temp .= 'Deactivate User</button></form></td></tr>';
					}
					else {
						$temp .= '<form method="POST"><button style="border:0px;" type="submit" onclick=' . 'activeUser(' . $row[0] . ')>';
						$temp .= 'Activate User</button></form></td></tr>';
					}
				}

			}
			$temp .= '</table>';
			echo $temp;
		}
	}

	global $dates;
	global $logins;
	global $users;
	global $notes;

	$dates = new Dated();
	$logins = new Login();
	$users = new User();
	$notes = new Note();
		if(isset($_GET['usr'])) { $users->uname = $_GET['usr']; } //
		if(isset($_GET['pw'])) { $users->password = $_GET['pw']; } //
		if(isset($_GET['newuser'])) { $users->newuser = $_GET['newuser']; } //
		if(isset($_GET['newpw'])) { $users->newpassw = $_GET['newpw']; } //
		if(isset($_GET['repw'])) { $users->repassw = $_GET['repw']; } //
		if(isset($_GET['moduser'])) { $users->moduser = $_GET['moduser']; } //
		if(isset($_GET['modgrp'])) { $users->modgrp = $_GET['modgrp']; } //
		if(isset($_GET['grp'])) { $users->usrlvl = $users->usrgrp = $_GET['grp']; } //
		if(isset($_GET['email'])) { $users->email = $_GET['email']; } //
		if(isset($_GET['singular'])) { $dates->singular = $_GET['singular']; } //
		if(isset($_GET['y'])) { $dates->year = $_GET['y']; } //
		if(isset($_GET['m'])) { $dates->month = $_GET['m']; } //
		if(isset($_GET['d'])) { $dates->day = $_GET['d']; } //
		if(isset($_GET['dy'])) { $dates->year = $_GET['dy']; } //
		if(isset($_GET['dm'])) { $dates->month = $_GET['dm']; } //
		if(isset($_GET['vacation'])) { $dates->vacation = $_GET['vacation']; } //
		if(isset($_GET['perm'])) { $dates->perm = $_GET['perm']; } //
		if(isset($_GET['length'])) { $dates->length = $_GET['length']; } //
		if(isset($_GET['dtls'])) { $dates->dtls = $_GET['dtls']; } //
		if(isset($_GET['all'])) { $dates->all = $_GET['all']; } //
		if(isset($_GET['inpw'])) { $logins->password = $_GET['inpw']; } //
		if(isset($_GET['inusr'])) { $logins->uname = $_GET['inusr']; } //
		if(isset($_GET['idx'])) { $users->indx = $_GET['idx']; } //
		if(isset($_GET['is_admin'])) { $users->adm = $_GET['is_admin']; } //
		if(isset($_GET['set_admin'])) { $users->setadm = $_GET['set_admin']; } //
		if(isset($_GET['recp'])) { $notes->to = $_GET['recp']; } //
		if(isset($_GET['dtls'])) { $users->desc = $_GET['dtls']; } //
		if(isset($_GET['begin'])) { $dates->begin = $_GET['begin']; } //
		if(isset($_GET['sched_whom'])) { $users->whom = $_GET['sched_whom']; } //
		if(isset($_SERVER['HTTP_ORIGIN'])) {
			$domaintok = md5("DfOdd@f" . $_SERVER['HTTP_ORIGIN'] . "sD1o0J");
			$users->utoken = $domaintok;
		} //

	function logout() {
		$logins->flag = 0;
	}

//
	function loginChallenge($data) {
		// The base_url (remote host)
		// is needed to protect users
		// Only 3 different remote hosts allowed
		// v--Not sure how to wrap JS and PHP
		$try = new Logger();
		$data->base_url = $_SERVER['HTTP_ORIGIN']; //check incoming IP
		
		$dbquery = 'SELECT USERNAME, PASSWORD, ADMIN, TOKEN ';
		$dbquery .= 'FROM user WHERE USERNAME = "' . $data->uname . '" AND TOKEN = "' . $data->utoken . '"';
		$dbquery .= ' AND ACTIVE = 1;';
		$results = $conn->query($dbquery);
		if (!$results) {
			echo "Login Error &lt;Step 1&gt;: " .
			$conn->error . "<br/><br/>";
			return;
		}
		else reset($_GET);
		if ($results) {
			$try->result = "Success";
			$try->attr = "Login";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		else {
			throwError("Invalid Login");
			$try->result = "Fail";
			$try->attr = "Login";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		$data->utoken = "DfOdd@f" . $_SERVER['HTTP_ORIGIN'] . "sD1o0J";
		$pastok = md5("BI@0d74i" . $data->inpw . "sD1o0J");
		$rows = $results->num_rows;
		for ($j = 0; $j < $rows;$j++) {
			$results->data_seek($j);
			$row = $results->fetch_array(MYSQLI_NUM);
			if ($pastok == $row[2] &&
				$data->inusr == $row[1] &&
				$data->utoken == $row[3]) {
				if ($row[3] == "1")
					$data->adm = "on";
				else $data->adm = "0";
				get_client_id($data);
				$try->result = "Success";
				$try->attr = "Login";
				$try->base_url = $_SERVER['REMOTE_ADDR']; $try->user = $data->uname;
				$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
				break;
			}
			else { $logins->flag = 0; }
		}

		if ($logins->flag == 1)
			fget_contents($logins->base_url);
		else {
			throwError("Invalid Login");
			$try->result = "Fail";
			$try->attr = "Login";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		Logger::logAll($try);
	}

//
	function commitChanges($data) {
		$try = new Logger();
		if (! isset($data->flag) || $data->flag != "on") {
			throwError("Logged Out");
			return;
		}
		if ($data->adm != "on") {
			throwError("You do not have adequate permissions"); $try->result = "Fail";
			$try->attr = "Commit Changes";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			Logger::logAll($try);
			return;
		}
		$dbquery = 'COMMIT;';
		$results = $conn->query($dbquery);
			if (!$results) {
				echo "SQL Error &lt;Commit&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
		else reset($_GET);
		if ($results) {
			$try->attr = "Commit";
			$try->result = "Success";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		else { $try->attr = "Commit"; $try->result = "Fail";
			 $try->base_url = $_SERVER['REMOTE_ADDR']; $try->user = $data->uname;
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		Logger::logAll($try);
	}

	function fget_contents($url) {
		$json = file_get_contents($url);
		$this->loadfromJSON($json);
	}
//
	function rollbackChanges($data) {
		$try = new Logger();
		if (! isset($data->flag) || $data->flag != "1") {
			throwError("Logged Out");
			return;
		}
		if ($data->adm != "on") {
			throwError("You do not have adequate permissions"); $try->result = "Fail";
			$try->attr = "Rollback Changes";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			Logger::logAll($try);
			return;
		}
		$dbquery = 'ROLLBACK;';
		$results = $conn->query($dbquery);
		if (!$results) {
			echo "SQL Error &lt;Rollback&gt;:" .
			$conn->error . "<br/><br/>";
			return;
		}
		else reset($_GET);
		if ($results) {
			$try->attr = "Rollback";
			$try->result = "Success";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		else { $try->attr = "Rollback"; $try->result = "Fail";
			 $try->base_url = $_SERVER['REMOTE_ADDR']; $try->user = $data->uname;
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		Logger::logAll($try);
	}
//
	function changePassword($data) {
		if ($_GET['old_passw'] == $data->password) {
		$pastok = md5("BI@0d74i" . $data->newpassw . "sD1o0J");
			if ($_GET['new_passw'] == $_GET['new_passw_rpt'])
				$dbquery = 'UPDATE user SET PASSWORD = "' . $hasher . '", ACTION = "' . $data->uname . '" WHERE USERNAME = "' . $data->uname . '";';
			$results = ($dbquery);
			if (!$results) {
				echo "Modify Error &lt;Password&gt;:" .
				$conn->error . "<br/><br/>";
				return;
			}
			else reset($_GET);
		}
		if ($results) {
			$try->attr = "Change Password";
			$try->result = "Success";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		else { $try->attr = "Change Password"; $try->result = "Fail";
			 $try->base_url = $_SERVER['REMOTE_ADDR']; $try->user = $data->uname;
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
	}

	function refreshering() {
		require("/PHP/workload.php");
	}

	function addUser($data) {
		$try = new Logger();
		if (! isset($data->flag) || $data->flag != "1") {
			throwError("Logged Out");
			return;
		}
		if ($data->adm != "on") {
			throwError("You do not have adequate permissions"); $try->result = "Fail";
			$try->attr = "Add User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			Logger::logAll($try);
			return;
		}
		$pastok = md5("BI@0d74i" . $data->newpassw . "sD1o0J");
		$domaintok = md5("DfOdd@f" . $_SERVER['HTTP_ORIGIN'] . "sD1o0J");
		$dbquery = 'SELECT USERNAME FROM user WHERE USERNAME = ' . $data->newuser . ' AND TOKEN = ' . $data->utoken . ';';
		$results = $conn->query($dbquery);
		if (!$results) {
			echo "Entry Error &lt;User (1)&gt;: " .
			$conn->error . "<br/><br/>";
			return;
		}
		if ($results->num_rows != 0) {
			echo "User Exists";
			return;
		}
		$dbquery = "INSERT INTO user VALUES";
		$dbquery .= '(NULL,"' . $domaintok . '","' . $data->newuser . '","' . $passtok . '","' . $data->setadm . '",NULL,"' . $data->email . '","' . $data->group . '",NULL)';

		$results = $conn->query($dbquery);
			if (!$results) {
				echo "Entry Error &lt;User (2)&gt;: " .
				$conn->error . "<br/><br/>";
				return;
			}
		else reset($_GET);
		if ($results) {
			$try->result = "Success";
			$try->attr = "Add User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		else { 
			throwError("Add User Denied"); $try->result = "Fail";
			$try->attr = "Add User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		Logger::logAll($try);
	}

	function addNote($data) {
		$try = new Logger();
		if (! isset($data->flag) || $data->flag != "1") {
			throwError("Logged Out");
			return;
		}
		$pastok = md5("BI@0d74i" . $data->password . "sD1o0J");
		$domaintok = md5("DfOdd@f" . $_SERVER['HTTP_ORIGIN'] . "sD1o0J");
		$data->date = date("Y") . '-' . date("m") . '-' . $date("j");
		$data->read = 0;
		$dbquery = 'INSERT INTO notes';
		$dbquery .= ' VALUES (NULL,"' . $data->date . '","' . $data->to . '","' . $data->from . '","' . $data->dtls . '","' . $domaintok . '","' . $data->read . '","' . $data->admins_only . '"';
		if ($data->adm == "on")
			$dbquery .= '","1",';
		else $dbquery .= '","0",';
		$dbquery .= '"' . $data->usrgrp . '");';
		$results = $conn->query($dbquery);
			if (!$results) {
				echo "Entry Error &lt;Notes&gt;: " .
				$conn->error . "<br/><br/>";
				return;
			}
		else reset($_GET);
		if ($results) {
			$try->result = "Success";
			$try->attr = "Add Note";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->from; $try->group = $users->grplvl;
		}
		else { 
			throwError("Add Note Denied"); $try->result = "Fail";
			$try->attr = "Add Note";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->from; $try->group = $users->grplvl;
		}
		Logger::logAll($try);
	}

	function remuser($data) {
		$try = new Logger();
		if (! isset($data->flag) || $data->flag != "1") {
			throwError("Logged Out");
			return;
		}
		if ($data->adm != "on") {
			throwError("You do not have adequate permissions"); $try->result = "Fail";
			$try->attr = "Remove User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
			Logger::logAll($try);
			return;
		}
		// Use $this to delete
		// from calendar db rows
		// delete hash file w/ dtls
		$dbquery = 'DELETE FROM user ';
		$dbquery .= 'WHERE ID = "' . $data->indx . '" AND GROUP_NO < "' . $data->usrlvl . '"';
		$dbquery .= ' AND TOKEN = "' . $data->utoken . '"';
		$results = $conn->query($dbquery);
			if (!$results) {
				echo "Remove Error &lt;User&gt;: " .
				$conn->error . "<br/><br/>";
				return;
			}
		else reset($_GET);
		if ($results) {
			$try->result = "Success";
			$try->attr = "Remove User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		else { 
			throwError("Denied User Removal"); $try->result = "Fail";
			$try->attr = "Remove User";  $try->base_url = $_SERVER['REMOTE_ADDR'];
			$try->user = $data->uname; $try->utoken = $data->utoken; $try->group = $data->usrgrp;
		}
		Logger::logAll($try);
	}

	function listSideNotes($data) {
		$results = array();

		$conn = new mysqli('localhost:3306','root','!3$!3$','dbs8105296');
		$dbquery = 'SELECT * FROM notes WHERE (RCPT = ';
		$dbquery .= '"' . $data->uname . '" AND TOKEN = "' . $data->utoken . '")';
		if ($data->adm == "on")
			$dbquery .= ' AND ADMINS_EYES = "1" OR GROUP_NO < "' . $data->usrgrp . '"';
		else $dbquery .= ' AND ADMINS_EYES = "0"';
		$dbquery .= ' AND SEEN = "0";';
		$results = $conn->query($dbquery);
		if (!$results) {
			echo "Listing Error &lt;Notes&gt;: " .
			$conn->error . "<br/><br/>";
			return;
		}
		else reset($_GET);
		$temp = '<table style="cursor:default;border:1px black solid;font-size:12px;">';

		$rows = $results->num_rows;
		if ($rows > 5)
			$y = 5;
		else $y = $rows;
		for ($x = 0; $x < $y; $x++) {
			$results->data_seek($x);
			$row = $results->fetch_array(MYSQLI_NUM);
			if ($row[9] > $data->usrgrp || ($row[7] == 1 && $data->adm != "on")) {
				$y++;
				continue;
			}
			$temp .= '<tr>';
			$temp .= '<td>' . $row[1] . '</td>';

			$temp .= '<td>';
			$temp .= $row[3];
			$temp .= '</td>';
			$temp .= '</tr>';

			$temp .= '<tr><td colspan=2>' . $row[4];
			$temp .= '</td></tr>';
			if ($row[7] == 1 && $data->adm == "on") {
				$temp .= '<tr><td colspan=2 style="color:red">Admins Only</td></tr>';
			}
			$temp .= '<tr><td colspan=2 style="border-bottom:1px black dashed;color:red;text-align:right">';
			if ($row[2] == $data->uname ||
				$row[9] < $data->usrgrp ||
				$row[3] == $data->uname) {
				$temp .= '<span onclick=' . 'readNote(' . $row[0] . ')>';
				$temp .= 'Mark Read</span></td></tr>';
			}
		}
		$temp .= '</table>';
		echo $temp;
	}

	function listNotes($data) {
		if (! isset($data->flag) || $data->flag != "1") {
			throwError("Logged Out");
		//	return;
		}
		$dbquery = 'SELECT * FROM notes WHERE RCPT = ';
		$dbquery .= '"' . $data->uname . '" AND TOKEN = "' . $data->utoken . '"';
		if ($data->adm == "on")
			$dbquery .= ' AND ADMINS_EYES = "1"';
		else $dbquery .= ' AND ADMINS_EYES = "0"';
		$dbquery .= ' AND SEEN = "0";';
		$results = $conn->query($dbquery);
			if (!$results) {
				echo "Listing Error &lt;Notes&gt;: " .
				$conn->error . "<br/><br/>";
				return;
			}
		else reset($_GET);
		$temp = '<table style="cursor:default;border:1px black solid;font-size:12px;">';

		$rows = $results->num_rows;
		for ($x = 0; $x < $rows; $x++) {
			$results->data_seek($x);
			$row = $results->fetch_array(MYSQLI_NUM);
			if ($row[9] > $data->usrgrp || ($row[7] == 1 && $data->adm != "on"))
				continue;
			$temp .= '<tr>';
			$temp .= '<td>' . $row[1] . '</td>';

			$temp .= '<td>';
			$temp .= $row[3];
			$temp .= '</td>';
			$temp .= '</tr>';

			$temp .= '<tr><td colspan=2>' . $row[4];
			$temp .= '</td></tr>';
			if ($row[7] == 1 && $data->adm == "on") {
				$temp .= '<tr><td colspan=2 style="color:red">Admins Only</td></tr>';
			}
			$temp .= '<tr><td colspan=2 style="border-bottom:1px black dashed;color:red;text-align:right">';
			if (($row[2] == $data->uname) ||
				($row[9] < $data->usrgrp && $data->adm == "on") ||
				$row[3] == $data->uname) {
				$temp .= '<span ';
				if ($row[8] == 1 && $data->adm != "on") {
					$temp .= 'style="color:blue">';
					$temp .= 'From Admin</span></td></tr>';
				}
				else {
					$temp .= 'onclick=' . 'readNote(' . $row[0] . ')>';
					$temp .= 'Mark Read</span></td></tr>';
				}
			}
		}
		$temp .= '</table>';
		echo $temp;
	}

	function markRead($data) {
		$dbquery = 'UPDATE notes SET SEEN = 1; WHERE ID = "' . $data->indx . '"';
		$dbquery .= ' AND TOKEN = "' . $data->utoken . '"';
		$results = $conn->query($dbquery);
		if (!$results) {
			echo "Read Error: " .
			$conn->error . "<br/><br/>";
			return;
		}
		else reset($_GET);
	}

	if (isset($_GET['login_change_password'])) {
		changePassword($users);
		reset($_GET['login_change_password']);
	}

	if (isset($_GET['read_notes'])) {
		markRead($_GET['read_notes']);
		reset($_GET['read_notes']);
	}

	if (isset($_GET['listing_notes'])) {
		listNotes($users);
		reset($_GET['listing_notes']);
	}

	if (isset($_GET['listing_side_notes'])) {
		listSideNotes($users);
//		reset($_GET['listing_side_notes']);
	}

	if (isset($_GET['login_credentials'])) {
		loginChallenge();
		reset($_GET['login_credentials']);
	}

	if (isset($_GET['add_users_func']) && $users->adm == "on") {
		adduser($users);
		reset($_GET['add_users_func']);
	}

	if (isset($_GET['list_users_func']) && $users->adm == "on") {
		$users->listUsers();
		reset($_GET['add_users_func']);
	}

	if (isset($_GET['rem_users_func']) && $users->adm == "on") {
		remuser($users);
		reset($_GET['rem_users_func']);
	}

	if (isset($_GET['add_date_func'])) {
		$dates->addDate($users);
		reset($_GET['add_date_func']);
	}

	if (isset($_GET['log_out_func'])) {
		$logout($users);
		reset($_GET['log_out_func']);
	}

	if (isset($_GET['rem_date_func'])) {
		remdate($users);
		reset($_GET['rem_date_func']);
	}

	if (isset($_GET['commit_changes']) && $users->adm == "on") {
		commitChanges($users);
		reset($_GET['commit_changes']);
	}

	if (isset($_GET['rollback_changes']) && $users->adm == "on") {
		rollbackChanges($users);
		reset($_GET['rollback_changes']);
	}

	if (isset($_GET['whois'])) {
		if (isset($_GET['user_sched']) && $_GET['user_sched'] != "") {
			$dates->user_sched = $_GET['user_sched'];
		}
		$dates->listSchedule($users);
		reset($_GET['whois']);
	}

	if (isset($_GET['whois_side'])) {
		$dates->listMySchedule($users);
		reset($_GET['whois_side']);
	}

	if (isset($_GET['list_my_notes'])) {
		listNotes($users);
		reset($_GET['list_my_notes']);
	}

	if (isset($_GET['add_note_func'])) {
		$notes->utoken = $users->utoken;
		$notes->from = $users->uname;
		addNote($notes);
		reset($_GET['add_note_func']);
	}

	if (isset($_GET['start_login'])) {
		loginChallenge();
	}

	if (isset($_GET['deactive_date'])) {
		$users->indx = $_POST['n'];
		deactivateDate();
		reset($_POST['n']);
	}

	if (isset($_GET['active_date'])) {
		$users->indx = $_POST['n'];
		activateDate();
		reset($_POST['n']);
	}

	if (isset($_GET['deactive_user'])) {
		$users->indx = $_POST['n'];
		deactivateUser($users);
		reset($_POST['n']);
	}

	if (isset($_GET['active_user'])) {
		$users->indx = $_POST['n'];
		activateUser($users);
		reset($_POST['n']);
	}

?>