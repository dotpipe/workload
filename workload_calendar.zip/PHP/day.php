	<script src="../js/scripts.js">
	</script>
<? session_start(); 
	require("serverside.php");

	$URL = "showMo";
	global $dy;
	$dy = date("j");
	global $mo;
	$mo = date("m");
	global $Yr;
	$Yr = date("Y");
	if(! isset($Yr)) { $Yr = date("Y"); }
	if(isset($_GET['m'])) { $mo = $_GET['m']; }
	if(isset($_GET['y'])) { $Yr = $_GET['y']; }
	if(isset($_GET['d'])) { $dy = 1; }
		if ($users->adm != "on")
			$disstrict = ' disabled';
		else $disstrict = '';
	echo '<form method="POST">';
	echo '<table style="text-align:top" border=1 width="50%" cellpadding="3"><tr>';
	echo '<td style="cursor:default">Start Time</td>';
	echo '<td style="cursor:default" colspan=2>Date of Event\'s End</td><td colspan=2>Whom? <input type="textbox" name="sched_whom"></td><td></td><td></td></tr>';
	echo '<tr><td style="text-align:center;border-top:1px black dotted;border-left:1px black dotted"><input type="time" value="9:00 step="900" name="timea"/></td>';
	echo '<td style="border-top:1px dotted black;" colspan=2><input type="date" style="width:225" min="1" name="length" value="1" width="5" required/></td>';
	echo '<td style="text-align:left;border-top:1px dotted black;border-right:1px dashed black;border-bottom:1px dotted black;cursor:default"><input type="checkbox" name="singular"/> For Self</td>';
	echo '<td style="text-align:left;border-top:1px black dotted;border-right:1px dotted black;text-align:center;cursor:default"><input type="checkbox" name="vaca"/> Vacation</td>';
	echo '<td style="font-size:32px;" rowspan="3"><button onclick=addDate() type="submit" style="border:0px;color:green;background-color:white;">+</button></td>';
	echo '<td style="font-size:32px;" rowspan="3"><span style="border:0px;color:black;background-color:white;cursor:pointer;" onclick=' . 'callPHPHead("month",' . $mo . ',' . $Yr . ',1)>x</span></td></tr>';
	echo '<td style="vertical-align:bottom;border-left:1px black dotted;cursor:default">End Time</td>';
	echo '<td style="border-bottom:1px black dotted;align:top" colspan=2><textarea style="height:50;width:225" name="dtls" value="Event" required>Event Details</textarea></td>';
	echo '<td style="border-left:1px black dotted;border-right:1px black solid;background-color:lightblue;padding-left:10px" colspan=2><span style="cursor:default;font-size:12px;">Enter Start & End times, choose different length if extends beyond one<br/>If for leave, set Vacation and End Date</span></td></tr>';
	echo '<tr><td style="text-align:center;border-left:1px black dotted;border-bottom:1px black dotted;border-right:0px black none;"><input type="time" value="5:00" name="timez"></td>';
	echo '<td style="border-bottom:1px black dotted;text-align:center"><input type="checkbox"' . $disstrict . ' name="perm"/> Permanent</td>';
	echo '<td style="text-align:center;color:red;border-bottom:1px dotted black"> <input type="checkbox"' . $disstrict . ' name="all"/> All Users</form></td>';
	echo '<td style="border-bottom:1px black solid;border-right:1px black solid;border-left:1px black dashed;background-color:lightblue;padding-left:10px;font-size:12px;" colspan=2><span style="color:red;cursor:default;">All Users</span> will commit this to groups lower than you</td>';
	echo '</tr></table>';

?>